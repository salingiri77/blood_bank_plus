<?php
class Useraccount_model extends CI_Model 
{

 function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }



    public function update_password($new_password , $user_check) {
        $condition = "user_account.username =" . "'" . $user_check . "' OR " . "user_detail.mobile =" . "'" . $user_check . "'";
        $this->db->select('*');
        $this->db->from('user_account');
        $this->db->join('mobile_verification','user_account.user_id =mobile_verification.user_id ');
        $this->db->where($condition);
        $this->db->update('password', $new_password);

        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }


    }


    public function select_account_details($userid){
        $this->db->select('username');
        $this->db->from('user_account');
        $this->db->where('user_id',$userid);
        $query = $this->db->get();
        return $query->row();
    }


    function user_check_username($username)
    {
        $this->db->select('*')->from('user_account');
        $this->db->where('username', $username);

        $query = $this->db->get();

        if($query->num_rows() > 0 ){
            return true;
        }
        else{
            return false;
        }
    }



    function form_insert3($data3){

        $this->db->insert('user_account', $data3);
        return $data3;

    }









    function select_users($user_id){

        $this->db->where('user_id !=',$user_id);
        $query = $this->db->get_where('user_account', ['username' => $this->input->post('user_name')]);
        echo $query->num_rows();


    }



    function select_user(){
        $query = $this->db->get_where('user_account', ['username' => $this->input->post('user_name')]);
        echo $query->num_rows();


    }




    public function update_user($data, $user_id) {
        $this->db->where('user_id', $user_id);
        $this->db->update('user_account', $data);

        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }


    }

    public function get_OldPass($user_id){


        $this->db->select('password');
        $this->db->where('user_id', $user_id);
        $this->db->from('user_account');
        $query = $this->db->get();
        return $query->row();
//        $this->db->where('user_id', $user_id);
//        $query = $this->db->get('user_account');
////        $row = $query->row();

    }




    public function checkOldPass($old_pass_hash,$user_id){
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('user_account');
        $row = $query->row();

        if($query->num_rows > 0){
            $row = $query->row();
            if($old_pass_hash == $row->password){
                return true;
            }else{
                return false;
            }
        }
    }


    public function change_password($password,$user_id){

        $this->db->where('user_id', $user_id);
        $this->db->update('user_account',$password);
        echo $this->db->affected_rows();
//        die();
        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }
//        $this->db->update('user_account',$password);
//        $this->db->where('password', $old_pass_hash);
//        if($this->db->affected_rows()>0){
//            return true;
//        }
//        else{
//            return false;
//        }



    }

    public function user_id_fetch($usercheck){
        $condition = "user_account.username =" . "'" . $usercheck . "' OR " . "user_detail.mobile_no =" . "'" . $usercheck . "'";
        $this->db->select('user_account.user_id');
        $this->db->from('user_account');
        $this->db->join('user_detail','user_account.user_id =user_detail.user_id ');
        $this->db->where($condition);
        $query = $this->db->get();
        return $query->row();
    }

    public function update_user_account($username,$userid){
        $this->db->where('user_id', $userid);
        $this->db->update('user_account', $username);
        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }
    }
    public function username_password($user_id){

        $this->db->select('username,password');
        $this->db->from('user_account');
        $this->db->where('user_id', $user_id);
        $query= $this->db->get();
        $result = $query->row();
        return $result;


    }



    function update_check_username($username,$userid)
    {
        $this->db->select('*')->from('user_account');
        $this->db->where('username', $username);
        $this->db->where('user_id !=',$userid);

        $query = $this->db->get();

        if($query->num_rows() > 0 ){
            return true;
        }
        else{
            return false;
        }
    }
}