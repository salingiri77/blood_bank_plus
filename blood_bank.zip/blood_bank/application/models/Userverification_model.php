<?php

class Userverification_model extends CI_Model
{

    function __construct() {
        parent::__construct();
    }



    public function user_email_status($user_id){

        $this->db->select('email_verified');
        $this->db->from('user_verification');
        $this->db->where('user_id', $user_id);
        $query= $this->db->get();
        $result = $query->row();
        return $result->email_verified;

    }


     function getCode($code){
        $this->db->select("user_id,email_verified,use_status");
        $this->db->from('user_verification');
        $this->db->where('email_code', "$code");
        $query = $this->db->get();
        return $query->result();
    }



    public function email_check($user_id){
        $this->db->where('user_id', $user_id);
        $this->db->from('user_verification');
        $num_res = $this->db->count_all_results();
        if ($num_res > 0) {
            return TRUE;
        } else {
            return FALSE;
        }

    }


    function user_verified($status,$code){
        $this->db->where('email_code', "$code");
        $this->db->update('user_verification', $status);



    }

    function email_verify($user_verify_data){

        $this->db->insert('user_verification', $user_verify_data);
        return $user_verify_data;

    }

}