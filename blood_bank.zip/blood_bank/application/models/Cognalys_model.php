<?php
class Cognalys_model extends CI_Model
{  
    function __construct()
    {
        parent::__construct();
    }


    function data_insert($data_verify){

        $this->db->insert('cognalys', $data_verify);
        return $data_verify;


    }
     function getKey($user_id){

             $this->db->select("keymatch,otpstart");
             $this->db->from('cognalys');
             $this->db->where('user_id', "$user_id");
             $query = $this->db->get();
             return $query->result();

}

    function update_count($data,$user_id){
        $this->db->where('user_id', $user_id);
        $this->db->update('cognalys', $data);
        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }
    }


    public function select_count($user_id){
        $this->db->select('count');
        $this->db->from('cognalys');
        $this->db->where('user_id', $user_id);
        $query = $this->db->get();
        $count= $query->row('count');
        return $count;

    }

    public function data_update($data_verify,$user_id){
        $this->db->where('user_id', $user_id);
        $this->db->update('cognalys', $data_verify);
        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }

    }

}