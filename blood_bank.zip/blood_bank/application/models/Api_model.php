<?php



class Api_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function user_check($username){
        $this->db->select('*')->from('user_account');
        $this->db->where('username', $username);

        $query = $this->db->get();

        if($query->num_rows() > 0 ){
            return true;
        }
        else{
            return false;
        }

    }

    function user_check_username($username)
    {
        $var = $this->user_check($username);

        if($var){
            return true;  //duplicate data
        }else{

            return false;
        }

    }


    function data_inserts($username)

    {

        $var = $this->user_checks($username);



        if($var){
            return true;
        }else{

            return false;
        }

    }




    function user_checks($username,$userid){

        //$userna= "suruchi";
        $this->db->select('username');
        $this->db->from('user_account');
        $this->db->where('user_id !=', $userid);


        $query = $this->db->get();

        if($query->num_rows() > 0 )
            return true;

        else
            return false;


    }

    function email_checks($email,$userid){

        //$userna= "suruchi";
        $this->db->select('email');
        $this->db->from('profile');
        $this->db->where('user_id !=', $userid);


        $query = $this->db->get();

        if($query->num_rows() > 0 )
            return true;

        else
            return false;


    }

    function user_checkss($username,$userid){

        //$userna= "suruchi";
        $this->db->select('username');
        $this->db->from('user_account');
        $this->db->where('user_id', $userid);


        $query = $this->db->get();

        if($query->num_rows() > 0 )
            return true;

        else
            return false;


    }

    function email_checkss($email,$userid){

        //$userna= "suruchi";
        $this->db->select('email');
        $this->db->from('profile');
        $this->db->where('user_id', $userid);


        $query = $this->db->get();

        if($query->num_rows() > 0 )
            return true;

        else
            return false;


    }

    function user_check_mobile($mobileno){
        $this->db->select('*')->from('user_detail');
        $this->db->where('mobile_no', $mobileno);

        $query = $this->db->get();
        //$result = $query->get('mobile_no');
        /* print_r($result); */


        if($query->num_rows() > 0 ){
            return true;
        }

        else{
            return false;
        }

    }

    function user_check_email($email){
        $this->db->select('*')->from('profile');
        $this->db->where('email', $email);

        $query = $this->db->get();

        if($query->num_rows() > 0 ){
            return true;
        }

        else{
            return false;
        }


    }


}