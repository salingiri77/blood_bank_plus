<?php

class Userdetail_model extends CI_model
{

     function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }



    function form_insert2($data2){

        $this->db->insert('user_detail', $data2);
        return $data2;

    }

    function select_mobile(){
        $query = $this->db->get_where('user_detail', ['mobile_no' => $this->input->post('mobile')]);
        echo $query->num_rows();

    }
    public function fetch_mobile_cog($user_id){
        $this->db->select('mobile_no');
        $this->db->where('user_id', $user_id);
        $this->db->from('user_detail');
        $query = $this->db->get();
        return $query->row();

    }


    function userid($mobile_number){

        $this->db->select('user_id');
        $this->db->where('mobile_no', $mobile_number);
        $this->db->from('user_detail');
        $query = $this->db->get();
        return $query->row();


    }

    function sec_dob($dob,$user_id){

        $this->db->select('dob');
        $this->db->where('user_id', $user_id);
        $this->db->where('dob', $dob);
        $this->db->from('user_detail');
        $num_res = $this->db->count_all_results();

        if ($num_res == 1) {
            return TRUE;
        } else {
            return FALSE;
        }

    }

    function sec_mobile($mobile_no,$user_id){

        $this->db->select('mobile_no');
        $this->db->where('user_id', $user_id);
        $this->db->where('alternate_no', $mobile_no);
        $this->db->from('user_detail');
        $num_res = $this->db->count_all_results();

        if ($num_res == 1) {
            return TRUE;
        } else {
            return FALSE;
        }


    }

    function sec_blood($blood,$user_id){

        $this->db->select('blood_group');
        $this->db->where('user_id', $user_id);
        $this->db->where('blood_group', $blood);
        $this->db->from('user_detail');
        $num_res = $this->db->count_all_results();

        if ($num_res == 1) {
            return TRUE;
        } else {
            return FALSE;
        }


    }



    public function user_mobile_email_check($mobileno){

        $this->db->select('user_id');
        $this->db->from('user_detail');
        $this->db->where('mobile_no', $mobileno);
        $query= $this->db->get();
        $result = $query->row();
        return $result->user_id;

    }




    public function select_user_details($userid){
        $this->db->select('name,per_address,mobile_no,gender,blood_group,dob,alternate_no,alternate_email,health_defects,last_donate_date,last_three_donate');
        $this->db->from('user_detail');
        $this->db->where('user_id',$userid);
        $query = $this->db->get();
        return $query->row();
    }



    public function update_user_detail($userdetail,$userid){
        $this->db->where('user_id', $userid);
        $this->db->update('user_detail', $userdetail);
        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }
    }



    public function update_blood_status($userdetail,$userid){
        $this->db->where('user_id', $userid);
        $this->db->update('user_detail', $userdetail);
        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }

    }


    function user_check_mobile($mobileno){
        $this->db->select('*')->from('user_detail');
        $this->db->where('mobile_no', $mobileno);

        $query = $this->db->get();
        //$result = $query->get('mobile_no');
        /* print_r($result); */


        if($query->num_rows() > 0 ){
            return true;
        }

        else{
            return false;
        }

    }

}