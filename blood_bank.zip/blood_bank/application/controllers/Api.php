<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class MY_api extends CI_Controller
{


    function __Construct()
    {
        parent::__Construct();
       $this->load->database();
        $this->load->model('Login_model');
        $this->load->model('Mobileverification_model');
        $this->load->model('Login_model');
        $this->load->model('Useraccount_model'); 
        $this->load->model('Userdetail_model'); 
        $this->load->model('Userverification_model'); 
        $this->load->model('Profile_model');  
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');


    }


    public function login()
    {
        $this->load->model('login');
        $username = $this->security->xss_clean($this->input->post('username'));

        $password = $this->security->xss_clean($this->input->post('password'));
        $hashed_pass = $this->Login_model->get_password($username);
        $hash=$hashed_pass->password;
//        print_r($hash);
        if( password_verify($password,$hash)){
            $userjson = array(
                'username' => $username,
                'password' => $password,
                'success' => '1'

            );
        }else{
            $userjson = array(
                'user_id' => null,
                'status' => '0',
                'msg' => 'user not login'
            );
        }
        $userjson = json_encode($userjson);
        echo $userjson;

//        $result = $this->Login_model->get_user($username, $password);





//      $data['user_detail'] = $this->session->get_userdata($username,$password);
//
//        if(count( $data['user_detail'])>1){
//
//
//           $login_json =json_encode($this->session->get_userdata($username,$password));
//            echo $login_json;
//
//        }else{
//            $userjson = array(
//                'user_id' =>null,
//                'status' =>'0',
//                'msg'=>'user not login'
//            );
//            $login_json =json_encode($userjson);
//           echo $login_json;
//        }

    }


    public function register()
    {
//        $data='';
//        $data2='';
//        $data3='';
//        $data_verify='';
//        $user_verify_data='';
//        $user_verify='';
//      //  $array1=$this->Insert_model->form_insert($data);
//      //  print_r($array1);
//        $array2=$this->Insert_model->form_insert2($data2);
//        print_r($array2);
//        $array3=$this->Insert_model->email_verify($user_verify_data);
//        print_r($array3);
//        $array4=$this->Insert_model->form_insert3($data3);
//        print_r($array4);
//        $array5=$this->Insert_model->data_insert($data_verify);
//        print_r($array5);
//        $array6=$this->Insert_model->value_insert($user_verify);
//        print_r($array6);

    }

//        $fullname=$this->security->xss_clean ($this->input->post('fullname'));
//        $bloodgroup=$this->security->xss_clean($this->input->post('blood'));
//        $mobileno=$this->security->xss_clean($this->input->post('mobile_no'));
//        $alternateno=$this->security->xss_clean($this->input->post('alt_phone'));
//        $gender=$this->security->xss_clean($this->input->post('gender'));
//        $dob=$this->security->xss_clean($this->input->post('dob'));
//        $tempaddress=$this->security->xss_clean( $this->input->post('temp_address'));
//        $peraddress=$this->security->xss_clean($this->input->post('per_address'));
//        $height=$this->security->xss_clean($this->input->post('height'));
//        $weight=$this->security->xss_clean( $this->input->post('weight'));
//        $username=$this->security->xss_clean($this->input->post('username'));
//        $password=$this->security->xss_clean($this->input->post('password'));
//        $email=$this->security->xss_clean($this->input->post('email'));
//
//
//
////
////
////
//        $registerarray=array(
//            'fullname'=> $fullname,
//            'bloodgroup'=>$bloodgroup,
//            'mobileno'=>$mobileno,
//            'alternateno'=>$alternateno,
//            'gender'=>$gender,
//            'dob'=>$dob,
//            'tempaddress'=>$tempaddress,
//            'peraddress'=>$peraddress,
//            'height'=>$height,
//            'weight'=>$weight,
//            'username'=>$username,
//            'password'=>$password,
//            'email'=>$email,
//
//        );
//        //$this->Api_model->data_insert($registerarray);
//
//        $array=$this->Api_model->data_insert($registerarray);
//
//
//
////        $register_json=json_encode($registerarray);
////        echo $register_json;
//        if(($array)>1){
//            $register=json_encode($this->Api_model->data_insert($registerarray));
//            echo $register;
//        } else{
//            $register=array(
//                'msg'=>'not register',
//                'success'=>'0'
//            );
//            $register_json=json_encode($register);
//            echo $register_json;
//
//        }
//
//
//    }


    public function password_forget()
    {


        $email = $this->input->post('email');
        $mobile_no=$this->input->post('mobile');
        $mobile="+977".$mobile_no;
      $this->load->model('Insert_model');
        $num_res=$this->Insert_model->check_emailMobile($email,$mobile);


        if ($num_res == 1) {
            // Make a small string (code) to assign to the user // to indicate they've requested a change of // password
            $code = mt_rand('5000', '200000');
            $data = array(
                'forgot_password' => $code,
            );

            if ($this->Insert_model->update_profile($data,$email)) {
                $to = $email;
                $link = "http://localhost:81/ci/MY_Home/new_password/" . $code;
                $this->load->library('email', array('mailtype' => 'html'));
                $this->email->initialize(array(

                    'protocol' => 'smtp',
                    'smtp_host' => 'smtp.sendgrid.net',
                    'smtp_user' => 'noreply@technorio.com',
                    'smtp_pass' => 'N0replyTec#n0ri0',
                    'smtp_port' => 587,
                    'crlf' => "\r\n",
                    'newline' => "\r\n"
                ));
                $this->email->from('noreply@bloodbankplus.org', 'BloodBank+');
                $this->email->to($to);

                $this->email->subject('Reset Password');
                $this->email->message('Please click the following link to reset your password: ' . "<html><a href=$link>Click Here</a></html>");
                if ($this->email->send()) {
                   $email_password_reset=array(
                       'user_email'=>$to,
                       'success'=>1
                   );
                    $email_password_json=json_encode($email_password_reset);
                    echo $email_password_json;

                }

            }


        }
    }



    public function update_password(){

        $usercheck = $this->input->post('usercheck');

        $new_password = $this->input->post('new_password');


        $result =  $this->PostModel->update_password($usercheck,$new_password);

        if ($result) {
            $result = array('status' => "success" );
            $info =json_encode($result);
            echo $info;
        }
        else{
            $result = array('status' => "unsuccess" );
            $info =json_encode($result);
            echo $info;
        }

    }




    public function view_details()
    {

        $usercheck = "Asmita";

        $user_id = $this->Insert_model->user_id_fetch($usercheck);
        $userid = $user_id->user_id;

        if ($userid) {
            $profile_details = $this->Insert_model->select_profile_details($userid);
            $user_account_details = $this->Insert_model->select_account_details($userid);
            $user_details = $this->Insert_model->select_user_details($userid);

            $user_detail_over = array(
                $profile_details,
                $user_account_details,
                $user_details
            );
            echo json_encode($user_detail_over);

        }
        else{
            $user_detail=array(
             //   "msg"=>
            );
        }
    }




    public function Update_userProfile(){



        $userid=$this->session->userdata('user_id');
           $email= $this->input->post('email');
        $temp_address= $this->input->post('temp_address');
        $height= $this->input->post('height');
        $weight= $this->input->post('weight');
         $username= $this->input->post('username');
        $fullname= $this->input->post('fullname');
//           $mobile= $this->input->post('mobile');
        $gender= $this->input->post('gender');
        $bloodgroup= $this->input->post('bloodgroup');
        $dob= $this->input->post('dob');
        $alter_no=$this->input->post('alter_mobile');
        $alter_email=$this->input->post('alter_email');
        $health_defects=$this->input->post('health_defects');
        $last_donate_date=$this->input->post('last_donate');
        $last_donate=$this->input->post('last_month');


//           echo "$email, $temp_address, $height,$weight, $fullname,$mobile,  $gender, $bloodgroup,$dob";

        $profile = array(
            'email'=>$email,
            'temp_address'=>$temp_address,
            'height'=>$height,
            'weight'=>$weight
        );
        $userdetail = array(
            'name' => $fullname,
            'gender'=>$gender,
            'blood_group'=>$bloodgroup,
            'alternate_no'=>$alter_no,
            'dob'=>$dob,
            'alternate_email'=>$alter_email,
            'health_defects'=>$health_defects,
            'last_donate_date'=>$last_donate_date,
            'last_three_donate'=>$last_donate
        );

        $username=array(
            'username'=>$username
        );


//           print_r($profile);
//           print_r($userdetail);
//
       if(($this->Insert_model->update_profile_detail($profile,$userid))||($this->Insert_model->update_user_detail($userdetail,$userid))|| ($this->Insert_model->update_user_account($username,$userid)))
       {
            $result = array('status' => "1" );
            $info =json_encode($result);

        }
        else{
            $result = array('status' => "0" );
            $info =json_encode($result);

        }

        echo $info;


    }




}

?>