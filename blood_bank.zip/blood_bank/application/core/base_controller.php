<?php

class MY_Home extends CI_Controller
{

    function __Construct()
    {
        parent::__Construct();


    }


}
class MY_api extends MY_Home {
    function __Construct()
    {
        parent::__Construct();


    }

}
?>