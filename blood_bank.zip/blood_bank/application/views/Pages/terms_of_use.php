
    <!-- Start main-content -->
    <div class="main-content">
        <!-- Section: inner-header -->
        <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="<?php echo base_url(); ?>public/images/terms6.png">
            <div class="container pt-100 pb-50">
                <!-- Section Content -->
                <div class="section-content pt-100">
                    <div class="row">
                    </div>
                </div>
            </div>
        </section>
       <!--  <div class="col-md-12">
            <h3 class="title">
                Terms And Conditions
            </h3>
        </div> -->
        <section class="position-inherit">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 scrolltofixed-container">
                        <div class="list-group scrolltofixed z-index-0 mb-60 visible-xs-12" style="color:black;">
                            <a href="#section-one" class="list-group-item smooth-scroll-to-target"><b>Who May Use the Blood Bank+ Service?</b></a>
                            <a href="#section-two" class="list-group-item smooth-scroll-to-target"><b>Privacy</b></a>
                            <a href="#section-three" class="list-group-item smooth-scroll-to-target"><b>Membership</b></a>
                            <a href="#section-four" class="list-group-item smooth-scroll-to-target"><b>Terms and Termination</b></a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div id="section-one" class="mb-50">
                            <div class="panel panel-danger">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Who May Use the Blood Bank+ Service?</h3>
                                </div>
                                <div class="panel-body">
                                    <p class="mb-20">
                                        <b>AGE REQUIREMENT:</b> </br>You must be at least 18 years old to use the Blood Bank+ Service.
                                    </p>
                                </div>
                            </div>
                            <div id="section-two" class="mb-50">
                                <div class="panel panel-danger">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Privacy</h3>
                                    </div>
                                    <div class="panel-body">
                                        <p class="mb-20">
                                            Your privacy rights are set forth in our Privacy Policy, which forms a part of this Agreement. Please review the Privacy Policy to learn about:
                                            What information we may collect about you;
                                            What we use that information for; and
                                            With whom we share that information.
                                        </p>
                                    </div>
                                </div>
                                <div id="section-three" class="mb-50">
                                    <div class="panel panel-danger">
                                        <div class="panel-heading">
                                            <h3 class="panel-title">Membership</h3>
                                        </div>
                                        <div class="panel-body">
                                            <p class="mb-20">
                                            <p>
                                                <b>REGISTRATION:</b><br/>To use the Blood Bank+ Service, you must register as a member by using your Facebook account along with your full name, date of birth, valid email address, mobile number, your blood group and current location. You must provide complete and accurate registration information to Blood Bank+. To register as a member into the system is absolutely free of cost while sending messages or calling donors or requesters through the system will be charged and deducted by your mobile network provider only.
                                            </p>
                                            <p>
                                                <b>ACCOUNT SECURITY:</b><br/>You are responsible for all activity that occurs under your account, including any activity by unauthorized users. If you become aware of an unauthorized access to your account, you must change your password and notify us immediately.
                                            </p>
                                            </p>
                                        </div>
                                    </div>
                                    <div id="section-four" class="mb-50">
                                        <div class="panel panel-danger">
                                            <div class="panel-heading">
                                                <h3 class="panel-title"> Terms and Termination</h3>
                                            </div>
                                            <div class="panel-body">
                                                <p class="mb-20">
                                                <p>
                                                    <b>TERMS:</b><br/> This Agreement begins on the date you first use the Blood Bank+ System and continues as long as you have an account with us. Blood Bank+ reserves the right to modify or discontinue the Blood Bank+ System with or without prior notice.
                                                </p>
                                                <p>
                                                    <b>TERMINATION FOR BREACH:</b><br/> Blood Bank+ may suspend, disable, or delete your account (or any part thereof) if Blood Bank+ determines that you have violated any provision of this Agreement or that your conduct or content would tend to damage reputation and goodwill of Blood Bank+. If Blood Bank+ deletes your account for the foregoing reasons, you may not re-register for the Blood Bank+ Service.
                                                <p>
                                                    <b>EFFECT OF TERMINATION:</b></br> Upon termination, all licenses granted by Blood Bank+ to you will be terminated.This Agreement constitutes the entire understanding between Blood Bank+ and you concerning the subject matter hereof and supersedes all prior agreements and understandings regarding the same.
                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
        </section>
    </div>
    <!-- end main-content -->
    <!-- Footer -->
    <!-- Footer -->
  