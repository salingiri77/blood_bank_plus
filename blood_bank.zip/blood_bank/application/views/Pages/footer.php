<footer class="footer p-0 bg-solid-color bg-black-111">
    <div class="container">
        <div class="row">
            <div class="footer-box-wrapper equal-height">
                <!--  <div class="col-sm-4 footer-box-one pr-0 pl-sm-0">
                     <div class="footer-box icon-box media">
                         <a href="#" class="media-left pull-left mr-30 mr-sm-15"><i class=" icon-ambulance14 text-white"></i></a>
                         <div class="media-body">
                             <h4 class="media-heading heading title">
                                 24 Hours Service
                             </h4>
                             <p>
                                 We provide 24 hours services for blood request.
                                 <a href="#"><i class="fa fa-arrow-circle-right font-14"></i></a>
                             </p>
                         </div>
                     </div>
                 </div> -->
                <div class="col-sm-6 footer-box-two pl-0 pr-0">
                    <div class="footer-box icon-box media">
                        <a class="media-left pull-left mr-30 mr-sm-15"><i class="fa fa-android text-white" aria-hidden="true"></i></a>
                        <div class="media-body">
                            <h4 class="media-heading title">
                                BloodBank+ App Coming Soon
                            </h4>
                            <p>
                                We also launching our android app through play store.

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 footer-box-three pl-0 pr-sm-0">
                    <div class="footer-box icon-box media">
                        <a class="media-left pull-left mr-30 mr-sm-15"><i class=" fa fa-credit-card text-white"></i></a>
                        <div class="media-body">
                            <h4 class="media-heading title">
                                Request blood through SMS.
                            </h4>
                            <p>
                                You can also use SMS service for register or request for blood.

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row equal-height">
            <div class="col-sm-4 col-md-3 border-right-black sm-height-auto">
                <div class="widget dark pt-50 pb-30 maxwidth400 sm-text-center">
                    <h5 class="widget-title">
                        Quick Links
                    </h5>
                    <ul>
                        <li><i class="fa fa-home text-white" aria-hidden="true"></i><a href="<?php echo base_url(); ?>" style="color:white;"> Home</a></li>
                        <li><i class="fa fa-info-circle text-white" aria-hidden="true"></i><a href="<?php echo base_url(); ?>#about" style="color:white; "> About</a></li>
                        <li><i class="fa fa-briefcase text-white" aria-hidden="true"></i><a href="<?php echo base_url(); ?>#how" style="color:white; "> How we work</a></li>
                        <li><i class="fa fa-question-circle text-white" aria-hidden="true"></i><a style="color:white;" href="faq"> FAQ</a></li>
                        <li><i class="fa fa-lock text-white" aria-hidden="true"></i><a href="privacy_policy" style="color:white;"> Privacy Policy</a></li>
                        <li><i class="fa fa-file text-white" aria-hidden="true"></i><a href="terms_of_use" style="color:white;"> Terms of Use</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-4 col-md-6 text-center border-right-black sm-height-auto">
                <!--twitter-->


<div class="col-sm-10 col-sm-offset-1">

              <!--twitter-->                <div class="widget dark text-right sm-text-center pt-50 pb-0 pt-xs-40 pb-xs-0 maxwidth400">

              <h5 class="widget-title" style="text-align: center;">GET CONNECTED</h5>

                   

              <div class=" ml-20">

              <a class="twitter-timeline" href="https://twitter.com/bloodbankplus">Tweets by bloodbankplus</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8" data-width="200 "  data-height="200"></script>

              </div>

           </div>

           </div>

           </div>

                       <div class="col-sm-4 col-md-3 sm-height-auto">
                <div class="widget dark text-right sm-text-center pt-50 pb-140 pt-xs-40 pb-xs-0 maxwidth400">
                    <h5 class="widget-title">Quick Contact</h5>
                    </h5>
                    <ul>
                        <li>
                            <i class="fa fa-phone-square text-white" aria-hidden="true"></i>
                            <a href="tel: +97714746103" style="color:white;">  +97714746103</a>
                        </li>
                        <li>
                            <i class="fa fa-phone text-white" aria-hidden="true"></i>
                            <a href="tel:+9779860484858" style="color:white; "> +9779860484858</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope text-white" aria-hidden="true"></i>
                            <a href="mailto:help@bloodbankplus.org" style="color:white;"> help@bloodbankplus.org</a>
                        </li>
                    </ul>
                    <ul class="social-icons icon-gray icon-circled icon-sm pull-right sm-pull-none sm-text-center mt-sm-15">
                        <li class="wow fadeInRight" data-wow-delay=".1s">
                            <a href="https://www.facebook.com/BloodBankPlus"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li class="wow fadeInRight" data-wow-delay=".2s">
                            <a href="https://www.twitter.com/BloodBankPlus"><i class="fa fa-twitter"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-nav bg-black-222 ">
        <div class="container pt-20 pb-10">
            <div class="row">
                <div class="col-md-12">
                    <p class="font-11 pull-left mb-sm-15 sm-text-center sm-pull-none para">
                        Copyright &copy;2016 BloodBankPlus. All Rights Reserved
                    </p>
                    <div class="widget m-0">
                        <ul class="font-11 pull-right text-right list-inline sm-text-center sm-pull-none">
                            <li>
                                <a href="<?php echo base_url(); ?>">Home</a>
                            </li>
                            <li>
                                /
                            </li>
                            <li>
                                <a href="<?php echo base_url(); ?>#about">About</a>
                            </li>
                            <li>
                                /
                            </li>
                            <li>
                                <a href="<?php echo base_url(); ?>#how">How we work?</a>
                            </li>
                            <li>
                                /
                            </li>
                            <li>
                                <a href="<?php echo base_url(); ?>#partners">Partners</a>
                            </li>
                            <li>
                                /
                            </li>
                            <li>
                                <a href="<?php echo base_url('faq'); ?>">FAQ</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<a class="scrollToTop" href="#" style="display: block;"><i class="fa fa-angle-up"></i></a>

<script src="<?php echo base_url(); ?>public/js/slick.min.js"></script>
<script type="text/javascript">
    $(document).on('ready', function () {

        $(".autoplay").slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000,
            dots: true,
            infinite: true,
            arrows:false,
             responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
});

</script>

<!--Datepicker-->
<script type="<?php echo base_url(); ?>js/parsley.min.js"></script>
<script type="text/javascript">
    $( function() {
        $("#datepicker").datepicker({
            minDate: new Date(1940, 0, 1),
            maxDate: new Date(1998, 11, 31),
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true
        });
    });
</script>
<script type="text/javascript">
    $( function() {
        $("#last_donate").datepicker({
            // minDate: new Date(1940, 0, 1),
            // maxDate: new Date(1997, 0, 1),
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true
        });
    });
</script>
<!--used in security_question -->
<script type="text/javascript">
    $( function() {
        $("#datepickers").datepicker({
            // minDate: new Date(1940, 0, 1),
            // maxDate: new Date(1997, 0, 1),
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true
        });
    });
</script>



<!-- JS | jquery plugin collection for this theme -->
<script src="<?php echo base_url(); ?>public/js/jquery-plugin-collection.js"></script>
<!-- Revolution Slider 5.x SCRIPTS -->
<script src="<?php echo base_url(); ?>public/js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="<?php echo base_url(); ?>public/js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
<script src="<?php echo base_url();?>public/js/js/bootstrap-dropdown.js">
</script>
<script src="<?php echo base_url();?>public/js/js/jquery.dataTables.min.js">
</script>
<script src="<?php echo base_url();?>public/js/js/jquery.ui.core.min.js">
</script>
<script src="<?php echo base_url();?>public/js/js/jquery.ui.widget.min.js">
</script>
<script src="<?php echo base_url();?>public/js/js/jquery.ui.datepicker.min.js">
</script>
<script src="<?php echo base_url();?>public/js/js/chosen.jquery.min.js">
</script>
<script src="<?php echo base_url();?>public/js/js/unique_check.js">
</script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.cdatepickom/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->


<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="<?php echo base_url();?>public/js/custom.js"></script>
<!-- SLIDER REVOLUTION 5.0 EXTENSIONS (Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading) -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.parallax.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/revolution-slider/js/extensions/revolution.extension.video.min.js"></script>
</body>
</html>