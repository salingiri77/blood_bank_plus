
	<!-- Start main-content -->
	<div class="main-content">
		<!-- Section: inner-header -->
		<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" style="background-image: url(<?php echo base_url(); ?>public/images/privacy4.png);" data-bg-img="<?php echo base_url(); ?>public/images/privacy4.png">
			<div class="container pt-100 pb-50">
				<!-- Section Content -->
				<div class="section-content pt-100">
					<div class="row">
					</div>
				</div>
			</div>
		</section>
		<section class="position-inherit">
			<div class="container">
				<div class="row">
					<div class="col-md-3 scrolltofixed-container">
						<div class="list-group scrolltofixed z-index-0 mb-60" style="color:black;">
							<a href="#section-one" class="list-group-item smooth-scroll-to-target "><b>Information We Collect About You</b></a>
							<a href="#section-two" class="list-group-item smooth-scroll-to-target"><b>Information you provide</b></a>
							<a href="#section-three" class="list-group-item smooth-scroll-to-target"><b>Information collected automatically</b></a>
							<a href="#section-four" class="list-group-item smooth-scroll-to-target"><b>How We Use the Information We Collect</b></a>
							<a href="#section-five" class="list-group-item smooth-scroll-to-target"><b>With Whom We Share Your Information</b></a>
							<a href="#section-six" class="list-group-item smooth-scroll-to-target"><b>How We Protect Your Personal Information</b></a>
							<a href="#section-seven" class="list-group-item smooth-scroll-to-target"><b>Changes to This Privacy Policy</b></a>
							<a href="#section-eight" class="list-group-item smooth-scroll-to-target"><b>How to Contact Us</b></a>
						</div>
					</div>
					<div class="col-md-9">
						<div id="section-one" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Information We Collect About You</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
										We may collect personal information that can identify you, such as your name, email address, contact details, and other information also that does identify you but required for the app like your blood group. When you provide personal information through our app, the information may be sent to our servers.
									</p>
								</div>
							</div>
						</div>

						<div id="section-two" class="mb-50">
								<div class="panel panel-danger">
									<div class="panel-heading">
										<h3 class="panel-title">Information you provide</h3>
									</div>
									<div class="panel-body">
										<p class="mb-20">
											We may collect and store any personal information you enter on our app or provide to us in some other manner like information through your Facebook account. This includes identifying information, such as your name, address, email address, mobile and telephone numbers, blood group; we also may request information about your gender and age, and other demographic information.
										</p>
									</div>
								</div>
						</div>
						<div id="section-three" class="mb-50">
									<div class="panel panel-danger">
										<div class="panel-heading">
											<h3 class="panel-title">Information collected automatically</h3>
										</div>
										<div class="panel-body">
											<p class="mb-20">
												We automatically collect your current location to show nearby blood donation campaigns on map and inform you about emergency need of blood in your current location.
											</p>
										</div>
									</div>
						</div>	
						<div id="section-four" class="mb-50">
										<div class="panel panel-danger">
											<div class="panel-heading">
												<h3 class="panel-title">How We Use the Information We Collect?</h3>
											</div>
											<div class="panel-body">
												<p class="mb-20">
													We may use information that we collect about you to:<br/>

													<span class="icon_stop"></span>Deliver the information to show in the app.<br/>
													<span class="icon_stop"></span>Perform research and analysis about blood donors, requesters, blood donations etc<br/>
													<span class="icon_stop"></span>Communicate with you by e-mail, mobile devices.<br/>
													<span class="icon_stop"></span>To facilitate your contact details to blood requester for sending message or calling you directly.<br/>
													<span class="icon_stop"></span>Enforce our terms and conditions.<br/>
												</p>
											</div>
										</div>
						</div>	
						<div id="section-five" class="mb-50">
											<div class="panel panel-danger">
												<div class="panel-heading">
													<h3 class="panel-title">With Whom We Share Your Information</h3>
												</div>
												<div class="panel-body">
													<p class="mb-20">
													<p>
														We want you to understand when and with whom we may share personal or other information we have collected about you or your activities on our app or while using our services. We do not share your personal information with others except as indicated below or when we inform you. We may share personal information with:
													</p>
													<b style="color:black;">
														Authorized service providers
													</b>
													<p>
														We may share your personal information with Nepal Red Cross Society. Nepal Red Cross Society may have access to personal information needed to perform their functions but are not permitted to share or use such information for any other purposes.
													</p>
													<b style="color:black;">
														Legitimate Bodies</b>
													<p>
														We also may disclose your information in response to a subpoena or similar investigative demand, a court order, or a request for cooperation from a law enforcement or other government agency; to establish or exercise our legal rights; to defend against legal claims; or as otherwise required by law. In such cases, we may raise or waive any legal objection or right available to us, in our sole discretion.
													</p>
													<p>
														When we believe disclosure is appropriate in connection with efforts to investigate, prevent, report or take other action regarding illegal activity, suspected fraud or other wrongdoing; to protect and defend the rights, property or safety of our company, our users, our employees, or others; to comply with applicable law or cooperate with law enforcement; or to enforce our app terms and conditions or other agreements or policies.
													</p>
													<b style="color:black;">
														Aggregated and non-personal information:
													</b>
													<p>
														We may share aggregated and non-personal information we collect under any of the above circumstances.
													</p>
													</p>
												</div>
											</div>
						</div>	
						<div id="section-six" class="mb-50">
												<div class="panel panel-danger">
													<div class="panel-heading">
														<h3 class="panel-title">How We Protect Your Personal Information</h3>
													</div>
													<div class="panel-body">
														<p class="mb-20">
															We take appropriate security measures (including physical, electronic and procedural measures) to help safeguard your personal information from unauthorized access and disclosure. For example, only authorized employees are permitted to access personal information, and they may do so only for permitted functions only. In addition, we use encryption in the transmission of your sensitive personal information between your system and ours, and we use firewalls to help prevent unauthorized persons from gaining access to your personal information.
															We want you to feel confident using our app. However, no system can be completely secure. Therefore, although we take steps to secure your information, we do not promise, and you should not expect, that your personal information, searches, or other communications will always remain secure. Users should also take care with how they handle and disclose their personal information and should avoid sending personal information through insecure email.
															Children’s Privacy
															This app is for those person only who is eligible for donating blood i.e. anyone with age of 18 or above it can donate the app and use this app for tracking his/her donation records. While we do not knowingly collect personal information from children under the age of 18.
														</p>
													</div>
												</div>
						</div>
						<div id="section-seven" class="mb-50">
													<div class="panel panel-danger">
														<div class="panel-heading">
															<h3 class="panel-title">Changes to This Privacy Policy</h3>
														</div>
														<div class="panel-body">
															<p class="mb-20">
																We will occasionally update this Privacy Policy to reflect changes in our practices and services. When we post changes to this Privacy Policy, we will revise the "Last Updated" date at the top of this Privacy Policy. We recommend that you check our app from time to time to inform yourself of any changes in this Privacy Policy or any of our other policies. We might inform our app users by sending an information message in the app itself also.
															</p>
														</div>
													</div>
						</div>	
						<div id="section-eight" class="mb-100">
														<div class="panel panel-danger">
															<div class="panel-heading">
																<h3 class="panel-title">How to Contact Us</h3>
															</div>
															<div class="panel-body">
																<p class="mb-20">
																	If you have any questions about this Privacy Policy or our information-handling practices, or if you would like to request information about our disclosure of personal information to third parties, please contact us by sending an email.
																<address style="color:black;">
																	Blood Bank+<br/>
																	support@bloodbankplus.com<br/>
																	© 2016 Blood Bank Plus,<br/>
																	All rights reserved.<br/>
																</address>
																</p>
															</div>
														</div>
						</div>
					</div>
		</section>
	</div>
	<!-- end main-content -->

	<!-- Footer -->
	<!-- Footer -->
	