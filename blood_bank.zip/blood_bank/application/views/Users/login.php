
    <div class="container" id="container">
      <style type="text/css" media="screen">
        body{
            background-image: url(<?php echo base_url();?>public/images/banner-sign-up.jpg);
        }
    </style>
        <div class="col-md-4 col-md-offset-4">
            <div class="row2">
<!--                <form class="ts-form" action="" method="POST">-->
                <?php echo form_open('login');?>

                <div id="alert">
<!--                    <a class="close" data-dismiss="alert"><i class="icon-remove"></i></a>-->
                <?php if(isset($message)){  ?>
                     <h4 class="alert alert-danger"><strong>Whoops!</strong> There was an error:</h4>
                    <strong><?php echo $message; ?></strong><br>
                <?php  }  ?>
            <br>    
                </div>
                <div id="alert">
                    <!--                    <a class="close" data-dismiss="alert"><i class="icon-remove"></i></a>-->
                    <?php if(isset($message123)){  ?>
                        <h4 class="alert alert-success"><strong>Congrats!</strong></h4>
                        <strong><?php echo $message123; ?></strong><br>
                    <?php  }  ?>
                    <br>
                </div>

                <?php if (validation_errors()) : ?>
                    <h3>Whoops! There was an error:</h3>
                    <p><?php echo validation_errors(); ?></p>
                <?php endif; ?>

                    <div class="ts-form-heading">

                        <fieldset>
                            <header class="head">
                                <strong class="heading">Log In</strong>
                            </header>
                        </fieldset></div>
                    <div class="ts-form-body">
                        <div class="form-group">
                            <?php echo form_input(array('id' => 'UserName', 'name' => 'username','class'=>'form-control','placeholder'=>'Username ','require' )); ?><br/>

                            <?php echo form_input(array('type'=>'password','id'=>'Password','name'=>'password','placeholder'=>'Enter your password','title'=>'Must contain at least one number and one uppercase and lowercase letter, and at least 7 or more characters','required','class'=>'form-control'))?>
                        </div>
                        <div class="form-group">

<!--                            --><?php //echo form_submit(array('name'=>'login_submit','Submit','class'=>'btn btn-primary','value'=>'Log In')); ?>
                       <button type="submit" name="login_submit" class="btn btn-primary"><span>LOG IN</span>
                                <i class="fa fa-check-circle" aria-hidden="true"></i>
                            </button>

                            <div class="small alternative-action text-muted"><a class="link" href="forget_password">Forgot password?</a>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <!-- Footer -->
   