
    <div class="container" id="container">
        <style type="text/css" media="screen">
        body{
            background-image: url(<?php echo base_url();?>public/images/banner-sign-up.jpg);
        }
    </style>
    <?php if(isset($random)){ echo $random ;} ?>
        <div class="col-md-4 col-md-offset-4">
            <div class="row2">
                <!--                <form class="ts-form" action="" method="POST">-->
                <?php echo form_open('forget_password') ; ?>
                <?php if (validation_errors()) : ?>
                    <h4 class="alert alert-danger"><strong>Whoops!</strong> There was an error:</h4>
                    <p><?php echo validation_errors(); ?></p>
                <?php endif;
                if(isset($message2)){ ?>
                    <h4 class="alert alert-danger"><strong>Whoops!</strong> There was an error </h4>
                    <p><?php echo $message2;  ?></p>
                <?php } 

                if(isset($message0)){ ?>
                    <h4 class="alert alert-danger"><strong>Whoops!</strong> There was an error </h4>
                    <p><?php echo $message0;  ?></p>
                <?php } ?>
                <br>
                <div class="ts-form-heading">

                    <fieldset>
                        <header class="head">
                            <strong class="heading">Forgot Password?</strong>
                        </header>
                    </fieldset></div>
                <div class="ts-form-body">
                    <div class="form-group">

                        <!--                            <input type="text" class="form-control" name="digit" id="user" pattern="^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Enter the Email" placeholder="Enter Email" autofocus="" required="">-->
                        <!--
                            <input type="number" name="number" id="" value="" class="form-control" name="digit" id="user" title="Enter the password" placeholder="Enter Phone Number" autofocus="" required="" style="margin-top:20px;">-->
                        <?php echo form_input(array('name' => 'mobile', 'id' => 'mobile','placeholder'=>'Enter Mobile', 'value' => set_value('mobile', ''), 'maxlength' => '100', 'size' => '50', 'style' => 'width:100%','class'=>'form-control','required')); ?>
                    </div>
                    <div class="form-group">
                        <!-- <button type="submit" class="btn btn-success center-block" name="submit">
                        Submit
                        </button>
                        -->
                        <!-- <input type="submit" class="center-block" name="submit"/> -->
                        <button type="submit" class="btn btn-primary"><span>SUBMIT</span>
                            <i class="fa fa-check-circle" aria-hidden="true"></i>
                        </button>
                        <!--                            --><?php //echo form_submit('submit', 'Submit'); ?>
                        <!--                            or --><?php //echo anchor('form', 'cancel'); ?>
                        <?php echo form_close(); ?>
                        <div class="small alternative-action text-muted"><a href="login_user">Cancel</a>
                        </div>
                    </div>
                </div>

                </form>
            </div>
        </div>
    </div>
    <!-- Footer -->
   