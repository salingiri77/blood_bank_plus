
    <div class="container" id="container">
    <style type="text/css" media="screen">
        body{
            background-image: url(<?php echo base_url();?>public/images/banner-sign-up.jpg);
        }
    </style>
        <div class="col-md-4 col-md-offset-4">
            <div class="row2">
<!--                <form class="ts-form" action="" method="POST">-->
        
                <?php if (validation_errors()) : ?>
                    <h4 class="alert alert-danger"><strong>Whoops!</strong> There was an error:</h4>
                    <p><?php echo validation_errors(); ?></p>
                <?php endif; ?>
              
                    <div class="ts-form-heading">

                        <fieldset>
                            <header class="head">
                                <strong class="heading">Security Question</strong>
                                <br>
                                <?php

                                $questions = array(

                                '1'=>'What is Your Date of Birth ?',
                                '2'=>'What is your Blood Group ?',
                                '3'=>'What was your Alternate Phone Number?'

                                );
                                 if(isset($random)){?>
                                <h4 class="alert alert-info"><?php echo $questions[$random];?></h4>
                              <?php  }?>

                            </header>
                        </fieldset></div>
                    <div class="ts-form-body">
                        <div class="form-group">
                                     <?php  $attributes = array('id' => 'register-form', 'autocomplete'=>'off');?>
            <?php echo form_open('security_question',$attributes);?>

            <?php  if($random == 1 ) { ?>

            <div class="row" style="width:280px;margin-left: 5px;">
              
               
                    <div class="form-group">

                        <?php echo form_label('Date of birth');?>
                        <div class="input-group">
                                        <span class="input-group-addon" style="height:45px;">
                                            <span class="glyphicon glyphicon-calendar" >
                                            </span>
                                        </span>
                            <?php echo form_input(array('class'=>'form-control','name'=>'dob','max'=>'1997-12-31' ,'placeholder'=>' E.g.1997-12-31 ', 'id'=>'datepickers' )) ;?>
                        </div>
                    </div>
               
            </div>

            <?php }  ?>

             <?php  if($random == 3 ) { ?>
            <div class="row" style="width:280px; margin-left: 5px;">
               
                    <div class="form-group">

                        <?php echo form_label('Mobile Number')?>
                        <div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-mobile" aria-hidden="true">
                                            </i>
                                        </span>
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'mobile_no', 'id'=>'mobile_no', 'placeholder'=>'E.g. 9xxxxxxxxx','onkeyup'=>'checkphone(); return false;', 'pattern'=>'[0-9]{10}','title'=>'Please enter 10 digit only','required' )) ;?>

                        </div>
                        <div  id="message2"></div>
                    </div>    
            </div>

            <?php  } ?>

              <?php  if($random == 2 ) { ?>
            <div class="row" style="width:280px;margin-left: 5px;">
                    <div class="form-group">

                        <?php echo form_label('Blood Group')?>
                        <br>
                        <div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-tint" aria-hidden="true">
                                            </i>
                                        </span>

                            <?php $bloodgroup=array(
                                'AP'=>'A+ (A Positive)',
                                'AN'=>'A- (A Negative)',
                                'BP'=>'B+ (B Positive)',
                                'BN'=>'B- (B Negative)',
                                'ABP'=>'AB+ (AB Positive)',
                                'ABN'=>'AB- (AB Negative)',
                                'OP'=>'O+ (O Positive)',
                                'ON'=>'O- (O Negative)'
                            )

                            ?>
                            <?php
                            echo form_dropdown( 'blood',$bloodgroup,'AP','class="form-control"','id="bloodg"' );
                            ?>

                        </div>
                    </div>

               
               
            </div>
           
           <?php } ?>
         

            <div class="row">
                <div class="col-lg-12">

                <?php 

                 if(isset($random)) { ?>

                    <div class="form-group" style="text-align:center; margin-top: 30px;">
                        <?php echo form_submit(array('name'=>'submit','value'=>'Submit','class'=>'btn btn-primary btn-lg btn-theme-colored btn-circled','width'=>'100%')); ?>

                    </div>

                    <?php } 

                    elseif(isset($message2)){ ?>
                               <h4 class="alert alert-danger"><strong>Whoops!</strong> There was an error </h4>
                               <p><?php echo $message2;  ?></p>

                                 <div class="form-group" style="text-align:center; margin-top: 30px;">
                       <a style="color:red;" href="forget_password"><u>Return Back</u></a>
                        </div>
                            
                           <?php  } else { ?>

                                <div class="form-group" style="text-align:center; margin-top: 30px;">
                       <a style="color:red;" href="forget_password" ><u>Return Back</u></a>
                        </div>
                            <?php }  ?>
                </div>
            </div>

                           
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
