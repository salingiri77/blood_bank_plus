$(document).ready(function() {
    $('#register-form').formValidation({
        framework: 'bootstrap',
        fields: {
            username: {
                message: 'The username is not valid',
                validators: {
                    // The validator will create an Ajax request
                    // sending { username: 'its value' } to the back-end
                    remote: {
                        message: 'The username is not available',
                        url: '<?php echo base_url?> MY_Home/register',
                        type: 'POST'
                    }
                }
            }
        }
    });
});