-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2016 at 02:22 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `cognalys`
--

CREATE TABLE `cognalys` (
  `sn` int(11) NOT NULL,
  `status` varchar(999) NOT NULL,
  `keymatch` varchar(999) NOT NULL,
  `user_id` int(11) NOT NULL,
  `otpstart` varchar(999) NOT NULL,
  `count` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cognalys`
--

INSERT INTO `cognalys` (`sn`, `status`, `keymatch`, `user_id`, `otpstart`, `count`) VALUES
(12, 'success', '414133ab7f154216aa6233c', 31, '+177421', 3),
(16, 'success', '3c7ff3c5c88945429a9218f', 36, '+177421', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `contact_id` int(11) NOT NULL,
  `name` char(200) NOT NULL,
  `email` char(200) NOT NULL,
  `subject` char(255) NOT NULL,
  `phone` char(200) NOT NULL,
  `message` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `index_text`
--

CREATE TABLE `index_text` (
  `id` int(11) NOT NULL,
  `text` mediumtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `index_text`
--

INSERT INTO `index_text` (`id`, `text`, `created`, `modified`) VALUES
(1, 'The text for blood bank plus goes here ...\r\nYou can add it from admin part .. Thank you !!!\r\n\r\nThe text for blood bank plus goes here ...\r\nYou can add it from admin part .. Thank you !!!\r\n\r\n\r\nThe text for blood bank plus goes here ...\r\nYou can add it from admin part .. Thank you !!!\r\n\r\n', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mobile_verification`
--

CREATE TABLE `mobile_verification` (
  `SN` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_verified` tinyint(1) NOT NULL,
  `v_code` varchar(999) NOT NULL,
  `mobile` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobile_verification`
--

INSERT INTO `mobile_verification` (`SN`, `user_id`, `is_verified`, `v_code`, `mobile`) VALUES
(5, 31, 1, '05fa676770944da8b91d894', '+9779843037860'),
(6, 36, 1, '4c0bf2ab5a3644bcbfb8e65', '+9779849632219');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `temp_address` varchar(999) DEFAULT NULL,
  `height` varchar(999) DEFAULT NULL,
  `weight` varchar(999) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `forgot_password` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`user_id`, `created`, `email`, `temp_address`, `height`, `weight`, `status`, `forgot_password`) VALUES
(31, NULL, 'sajan.giri@gmail.com', 'bhaktapur', '155', '55', 1, NULL),
(36, NULL, 'joshi.ujawal1@gmail.com', 'kalimati', '165', '60', 1, 194315),
(37, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `sn` int(11) NOT NULL,
  `password` varchar(999) NOT NULL,
  `last_login_ip` varchar(999) DEFAULT NULL,
  `last_login_date` varchar(999) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`sn`, `password`, `last_login_ip`, `last_login_date`, `user_id`, `username`) VALUES
(18, '$2y$10$5OqdztbqG2y2GqB2xTPOhOYoRE3CNtweN40d5QModksyml9rBx4iy', '::1', 'Male', 31, 'salingiri77'),
(23, '$2y$10$OsjwsQ06X2.pzr5P4Q.J..aH24H3gDfrDLGPeng922FntGzWueGPO', '::1', 'Male', 36, 'ujawal'),
(24, '489773', NULL, NULL, 37, 'BP170543');

-- --------------------------------------------------------

--
-- Table structure for table `user_detail`
--

CREATE TABLE `user_detail` (
  `sn` int(11) NOT NULL,
  `name` varchar(555) NOT NULL,
  `per_address` varchar(555) DEFAULT NULL,
  `gender` varchar(555) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `blood_group` varchar(555) NOT NULL,
  `mobile_no` varchar(55) DEFAULT NULL,
  `dob` varchar(555) DEFAULT NULL,
  `alternate_no` varchar(255) DEFAULT NULL,
  `alternate_email` varchar(225) DEFAULT NULL,
  `health_defects` varchar(30) DEFAULT NULL,
  `last_donate_date` date DEFAULT NULL,
  `last_three_donate` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_detail`
--

INSERT INTO `user_detail` (`sn`, `name`, `per_address`, `gender`, `user_id`, `blood_group`, `mobile_no`, `dob`, `alternate_no`, `alternate_email`, `health_defects`, `last_donate_date`, `last_three_donate`) VALUES
(19, 'salingiri777', 'bhaktapur', 'Female', 31, 'OP', '9843037861', '1988-01-07', '9818310674', '', 'No', '0000-00-00', 'No'),
(24, 'Ujawal', 'Hetauda-3', 'Male', 36, 'AP', '9849632219', '1996-01-02', '9849632219', 'ujawal.joshi@yahoo.com', 'No', '0000-00-00', 'No'),
(25, 'SALINGIRI', NULL, NULL, 37, '', '9818310675', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_verification`
--

CREATE TABLE `user_verification` (
  `sn` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email_verified` tinyint(1) NOT NULL,
  `email_code` varchar(999) NOT NULL,
  `created` datetime NOT NULL,
  `use_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_verification`
--

INSERT INTO `user_verification` (`sn`, `user_id`, `email_verified`, `email_code`, `created`, `use_status`) VALUES
(18, 31, 0, 'AihQuRBmURxRauiprFkKlrFXiCjnXUDNfoLUzHlmvEWizyIbfyuKBezUwtyCJuhypjeMkgLZspsokFps', '0000-00-00 00:00:00', 0),
(19, 36, 1, 'PhpWqkcaDNvWGOugGCsbIenLZxeCUinSPIArlZSPVAKrWxBfwjRogzbhZnlUIFqFgKonOgSarSqfcfUS', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `verification_provider`
--

CREATE TABLE `verification_provider` (
  `user_id` int(11) NOT NULL,
  `provider_name` varchar(999) NOT NULL,
  `api_url` varchar(999) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cognalys`
--
ALTER TABLE `cognalys`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `index_text`
--
ALTER TABLE `index_text`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobile_verification`
--
ALTER TABLE `mobile_verification`
  ADD PRIMARY KEY (`SN`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`sn`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `user_detail`
--
ALTER TABLE `user_detail`
  ADD PRIMARY KEY (`sn`),
  ADD UNIQUE KEY `mobile_no` (`mobile_no`);

--
-- Indexes for table `user_verification`
--
ALTER TABLE `user_verification`
  ADD PRIMARY KEY (`sn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cognalys`
--
ALTER TABLE `cognalys`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `index_text`
--
ALTER TABLE `index_text`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `mobile_verification`
--
ALTER TABLE `mobile_verification`
  MODIFY `SN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `user_account`
--
ALTER TABLE `user_account`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `user_detail`
--
ALTER TABLE `user_detail`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `user_verification`
--
ALTER TABLE `user_verification`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
