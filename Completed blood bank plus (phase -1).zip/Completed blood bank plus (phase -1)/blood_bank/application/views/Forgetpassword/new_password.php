
    <div class="container" id="container">
      <style type="text/css" media="screen">
        body{
            background-image: url(<?php echo base_url();?>public/images/banner-sign-up.jpg);
        }
    </style>
        <div class="col-md-4 col-md-offset-4">
            <div class="row2">
<!--                <form class="ts-form" action="" method="POST">-->
                <?php echo form_open('new_password') ; ?>
                <?php if (validation_errors()) : ?>
                    <h3>Whoops! There was an error:</h3>
                    <p><?php echo validation_errors(); ?></p>
                <?php endif; ?>

                <?php if (isset($submit_success)) : ?>
                    <h3>Email Sent:</h3>
                    <p>An email has been sent to the address provided.</p>

                    <script type="text/javascript">$('#alert').hide()</script>
                <?php endif; ?>
                    <div class="ts-form-heading">
                        <!-- <h3>
                        Please enter the last
                        <span class="red">
                                Five Digits
                        </span>
                        </h3> -->
                        <fieldset>
                            <header class="head">
                                <strong class="heading">Reset Password</strong>
                            </header>
                        </fieldset></div>
                    <div class="ts-form-body">
                        <div class="form-group">
<!--                            <input type="text" class="form-control" name="digit" id="user" pattern="^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Enter Email" placeholder="Enter Email" autofocus="" required="">-->
<!--                            <input type="password" name="password" id="" value="" class="form-control" name="digit" id="user" title="Enter the password" placeholder="Enter New Password" autofocus="" required="" style="margin-top:20px;">-->
                           <?php echo form_input(array('name' => 'email', 'id' => 'email','placeholder'=>'Enter Email', 'value' => set_value('email', ''), 'maxlength' => '100', 'size' => '50', 'style' => 'width:100%','class'=>'form-control','required')); ?>
                          <br/> <?php echo form_password(array('name' => 'password1','placeholder'=>'Enter Password', 'id' => 'password1', 'value' => set_value('password1', ''), 'maxlength' => '100', 'size' => '50', 'style' => 'width:100%','class'=>'form-control','required')); ?>
                            <br/>   <?php echo form_password(array('name' => 'password2','placeholder'=>'Confirm Password', 'id' => 'password2', 'value' => set_value('password2', ''), 'maxlength' => '100', 'size' => '50', 'style' => 'width:100%','class'=>'form-control','required')); ?>
<!--   <input type="password" name="password" id="" value="" class="form-control" name="digit" id="user" title="Enter the password" placeholder="Confirm Password" autofocus="" required="" style="margin-top:20px;">-->

                            <br> <?php echo form_input(array('name' => 'code', 'id' => 'code','placeholder'=>'Enter Your Code','maxlength' => '100', 'size' => '50', 'style' => 'width:100%','class'=>'form-control','required')); ?>
                        </div>
                        <div class="form-group">

                            <button type="submit" class="btn btn-primary"><span>SUBMIT</span>
                                <i class="fa fa-check-circle" aria-hidden="true"></i>
                            </button>
                            <div class="small alternative-action text-muted"><a href="login_user">Cancel</a>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <!-- Footer -->
 