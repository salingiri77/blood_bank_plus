
    <!-- Start main-content -->
    <div class="container" id="container">

     <style type="text/css">
        body{
            background-image: url(<?php echo base_url();?>public/images/banner-sign-up.jpg);
        }

    </style>

        <?php if (isset($_SESSION['submit_success'])) : ?>
            <h3>Email Sent:</h3>
            <p>An email has been sent to the address provided.</p>
            <script type="text/javascript">$('#alert').hide()</script>
        <?php
            $this->session->unset_userdata('submit_success');
        endif; ?>
        <div class="col-md-4 col-md-offset-4">
            <div class="row2">
                <form class="ts-form" action="user_check" method="POST">
                    <div class="ts-form-heading">

                        <fieldset>
                            <header class="head">
                            <?php if(!isset($error) && !isset($miscall) && !isset($data) && !isset($_SESSION['submit_usercheck']) ) {  ?>
                            <h5 class="alert alert-info">You will receive a miscall in a while..Please wait</h5>
                            <?php }  ?>
                                <strong class="heading">Please enter the last
                                    Five Digits</strong>
                            </header>

                            <?php if(isset($error)){ ?>
                                <h6 class="alert alert-danger"><strong>Whoops ! There was an Error !!!</strong></h6>
                                <?php echo $error; ?>
                          <?php  } ?>

                           <?php if(isset($miscall)){ ?>
                                <h6 class="alert alert-info"><strong>Notice !!!</strong>
                                <?php echo $miscall; ?></h6>
                          <?php  } ?>

                            <?php if(isset($data)){ ?>
                                <h6 class="alert alert-danger"><strong>Whoops ! There was an Error !!!</strong>
                                <?php echo $data; ?></h6>
                          <?php  } ?>

                            <?php if (isset($_SESSION['submit_usercheck'])) : ?>
                                    <h5 class="alert alert-danger">Mobile number NOT VERIFIED yet .Click RESEND to verify your number now !!</h5>
                                    <script type="text/javascript">$('#alert').hide()</script>
                            <?php
                                $this->session->unset_userdata('submit_usercheck');
                            endif; ?>
                    </div>
                    <div class="ts-form-body">
                        <div class="form-group">
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'digits','id'=>'user','type' =>'number','pattern'=>'{5}','required'=>'required')) ;?>
                        </div>
                        <div class="form-group">

                            <?php      $submit = array(
                                'name' => 'submit',
                                'class' => 'btn btn-primary center-block',
                                'type' => 'submit',
                                'content' => 'Submit  <i class="fa fa-check fa-fw"></i>'
                            );
                            echo form_button($submit);?>

                        </div>
                    </div>
                </form>
                <form class="ts-form" action="reCognlys" method="POST">
                    <?php      $data = array(
                        'name' => 'refresh',
                        'class' => 'btn btn-link center',
                        'type' => 'submit',
                        'content' => 'Resend <i class="fa fa-refresh" aria-hidden="true"></i>'
                    );

                    echo form_button($data);?>
                    </form>
                    </fieldset>

            </div>
        </div>
    </div>
    <!-- /slider -->
    <!-- Footer -->
  

