
<div class="col-lg-8 col-lg-offset-2">


    <style type="text/css">


        body{
            background-image: url(<?php echo base_url();?>public/images/banner-sign-up.jpg);
        }
    </style>
    <div id="alert">
        <!--                    <a class="close" data-dismiss="alert"><i class="icon-remove"></i></a>-->

<?php if(isset($message)){   ?>
        <h4 class="alert alert-danger"> <strong><?php  echo $message;  ?></strong></h4><?php }    ?>
        <?php if(isset($email_message)){   ?>
            <h4 class="alert alert-danger"> <strong><?php  echo $email_message;  ?></strong></h4><?php }    ?>
        <?php if(isset($mobile_message)){   ?>
            <h4 class="alert alert-danger"> <strong><?php  echo $mobile_message;  ?></strong></h4><?php }    ?>
        <?php if(isset($username_message)){   ?>
            <h4 class="alert alert-danger"> <strong><?php  echo $username_message;  ?></strong></h4><?php }    ?>
        <?php if (validation_errors()) : ?>
            <h3>Whoops! There was an error:</h3>
            <p><?php echo validation_errors(); ?></p>
        <?php endif; ?>

    </div>
    <div class="well" style="margin-top:20px;">
        <fieldset>
            <legend>
                <center>Register As a Donor</center>
            </legend>
            <?php  $attributes = array('id' => 'register-form', 'autocomplete'=>'on');?>
            <?php echo form_open('register',$attributes);?>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <?php  echo form_label('Full Name');?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-user" aria-hidden="true">
											</i>
										</span>
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'fullname', 'id'=>'fullname', 'placeholder'=>'E.g. Shyam Khadka','required'=>'required','value'=> set_value('fullname'))) ;?>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Username')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-user" aria-hidden="true">
											</i>
										</span>
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'username','id'=>'username','placeholder'=>'E.g.Shyam Khadka','required'=>'required','value'=> set_value('username')));?>
                        </div>
                        <div  id="message1"></div>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Gender');?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-intersex" aria-hidden="true">
											</i>
										</span>

                            <?php $gender=array(
                                'Male'=>'Male',
                                'Female'=>'Female',
                                'BP'=>'Other'

                            );

                            echo form_dropdown( 'gender',$gender,'AP','class="form-control"','id="gender"');?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Date of birth');?>
                        <div class="input-group">
										<span class="input-group-addon" style="height:45px;">
											<span class="glyphicon glyphicon-calendar" >
											</span>
										</span>
                            <?php echo form_input(array('class'=>'form-control','name'=>'dob','max'=>'1997-12-31' ,'placeholder'=>' E.g.1997-12-31 ', 'id'=>'datepicker','required'=>'required','value'=> set_value('dob') )) ;?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Mobile Number')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-mobile" aria-hidden="true">
											</i>
										</span>
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'mobile_no', 'id'=>'mobile_no', 'placeholder'=>'E.g. 9xxxxxxxxx','onkeyup'=>'checkphone(); return false;', 'pattern'=>'[0-9]{10}','title'=>'Please enter 10 digit only','required'=>'required','value'=> set_value('mobile_no') )) ;?>

                        </div>
                        <div  id="message2"></div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Alternate Number')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-mobile" aria-hidden="true">
											</i>
										</span>

                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'alt_phone', 'placeholder'=>' E.g. 9xxxxxxxxx or 014xxxxxx', 'pattern'=>'[0-9]{9,10}','title'=>'Please enter if mobile only is 10 digits or lanline is 9 digits only','value'=> set_value('alt_phone'))) ;?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Blood Group')?>
                        <br>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-tint" aria-hidden="true">
											</i>
										</span>

                            <?php $bloodgroup=array(
                                'AP'=>'A+ (A Positive)',
                                'AN'=>'A- (A Negative)',
                                'BP'=>'B+ (B Positive)',
                                'BN'=>'B- (B Negative)',
                                'ABP'=>'AB+ (AB Positive)',
                                'ABN'=>'AB- (AB Negative)',
                                'OP'=>'O+ (O Positive)',
                                'ON'=>'O- (O Negative)'
                            )

                            ?>
                            <?php
                            echo form_dropdown( 'blood',$bloodgroup,'AP','class="form-control"','id="bloodgroup"' );
                            ?>

                        </div>
                    </div>

                </div>
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Email')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-envelope" aria-hidden="true">
											</i>
										</span>

                            <?php echo form_input(array('class'=>'form-control','name'=>'email', 'id'=>'email','pattern'=>'^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$','placeholder'=>'E.g. john.doe@gmail.com','title'=>'Please enter the valid the email address having @ and period(.)','required'=>'required','value'=> set_value('email')));?>

                        </div>
                        <div  id="message"></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Temporary Address')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-map-marker" aria-hidden="true">
											</i>
										</span>
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'temp_address', 'placeholder'=>'E.g. Kalimati,Kathmandu','required'=>'required','value'=> set_value('temp_address')));?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Permanent Address')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-map-marker" aria-hidden="true">
											</i>
										</span>
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'per_address', 'placeholder'=>'E.g. Teku,Kathmandu','required'=>'required','value'=> set_value('per_address')));?>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Body Status-->
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Height')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-arrows-v" aria-hidden="true"></i>
										</span>
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'height', 'placeholder'=>'E.g. 165cm','pattern'=>'[0-9]{3}','title'=>'Must contain three numeric number only','required'=>'required','value'=> set_value('height')));?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Weight')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<span class="glyphicon glyphicon-scale"></span>
										</span>
                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'weight', 'placeholder'=>'E.g. 55kg','pattern'=>'[0-9]{2,3}','title'=>'Must contain three numeric number only or body weight must be 50kg or above','required'=>'required','value'=> set_value('weight')));?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <?php echo form_label('Password')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-lock" aria-hidden="true">
											</i>
										</span>	<span id="confirmMessage" class="confirmMessage">
									</span>

                            <?php echo form_password(array('class'=>'form-control','name'=>'password', 'id'=>'password','title'=>'Must contain 1 uppercase 1 lowercase and 1 numeric value','pattern'=>'(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}','required'=>'required'));?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">

                        <?php echo form_label('Confirm Password')?>
                        <div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-lock" aria-hidden="true">
											</i>
										</span>
                            <?php echo form_password(array('class'=>'form-control','name'=>'rpassword', 'id'=>'rpassword','pattern'=>'(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}','required'=>'required'));?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">

                    <div class="form-group mt-20" style="text-align:center; ">
                        <?php echo form_submit(array('name'=>'submit','value'=>'Register','class'=>'btn  btn-theme-colored btn-circled')); ?>

                    </div>
                </div>
            </div>

        </fieldset>


    </div>
</div>
<div class="clearfix"></div>
<!-- Footer -->
