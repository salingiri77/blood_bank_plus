
    <!-- Start main-content -->

<?php
$a = array();
$count = 0;
foreach ($detail as $data){
    foreach ($data as $sub) {
        $a[$count++] = $sub;
    }
}

$email = $a[0];
$temp_address=$a[1];
$height=$a[2];
$weight=$a[3];
$username=$a[4];
$fullname=$a[5];
$per_address=$a[6];
$mobile=$a[7];
$gender=$a[8];
$bloodgroup=$a[9];
$dob=$a[10];
$alter_mobile=$a[11];
$alter_email=$a[12];
$health_defect=$a[13];
$last_donate_date=$a[14];
$last_month=$a[15];?>

<?php   if($bloodgroup=='OP'){
    $bg="O Positive";
}

if($bloodgroup=='ON'){
    $bg="O Negative";
}

if($bloodgroup=='AP'){
    $bg="A Positive";
}
if($bloodgroup=='AN'){
    $bg="A Negative";
}
if($bloodgroup=='BP'){
    $bg="B Positive";
}
if($bloodgroup=='BN'){
    $bg="B Negative";
}
if($bloodgroup=='ABP'){
    $bg="AB Positive";
}
if($bloodgroup=='ABN'){
    $bg="AB Negative";
}

?>
    <div class="main-content">
        <div class="container">
            <div class="portlet light bg-inverse mt-20">
                <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="pill" href="<?php echo base_url(); ?>MY_Home/userProfile#home">View Profile</a></li>
                    <li><a data-toggle="pill" href="<?php echo base_url(); ?>MY_Home/userProfile#edit">Edit Profile</a></li>
                    <li><a data-toggle="pill" href="<?php echo base_url(); ?>MY_Home/userProfile#blood">Blood Status</a></li>

                    <li><a data-toggle="pill" href="<?php echo base_url(); ?>MY_Home/userProfile#password">Change Password</a></li>

                    <!--<button type="button" name="logout" onclick="window.location='--><?php //echo base_url("MY_Home/logout");?>


                    <!--  <li><a data-toggle="pill" href="#menu3">Menu 3</a></li> -->
                </ul>

                <div class="tab-content">
                    <div id="home" class="tab-pane fade in active">
                        <form class="form-horizontal" role="form" autocomplete="off">
                            <div class="form-body">
                                <h2 class="margin-bottom-20">
                                    <?php if (validation_errors()) {?>
                                        <h4 class="alert alert-danger"><strong>Whoops! </strong> There was an error:</h4>
                                        <p ><?php echo validation_errors(); ?></p>
                                    <?php } ?>
                                    <?php if(isset($update_success)) { ?>

                                        <h4 class="alert alert-success"><strong>Congrats !</strong> Update Success.
                                            <?php  echo $update_success; ?></h4>
                                    <?php  } ?>

                                    <?php if(isset($suc_msg)) { ?>

                                        <h4 class="alert alert-success"><strong>Congrats !</strong> Update Success.
                                            <?php  echo $suc_msg; ?></h4>
                                    <?php  } ?>

                                    <?php if(isset($fail_mesge)) { ?>

                                        <h4 class="alert alert-danger"><strong>Whoops !</strong> Update Failed.
                                            <?php  echo $fail_mesge; ?></h4>
                                    <?php  } ?>

                                    <?php if(isset($suc_mesge)) { ?>

                                        <h4 class="alert alert-success"><strong>Congrats !</strong> Update Success.
                                            <?php  echo $suc_msg; ?></h4>
                                    <?php  } ?>

                                    <?php if(isset($msg)) { ?>

                                        <h4 class="alert alert-danger"><strong>Whoops!</strong> Update failed.
                                            <?php  echo $msg; ?></h4>
                                    <?php  } ?>
                                    <?php if(isset($message)){ ?>

                                        <h4 class="alert alert-danger"><strong>Whoops!</strong> Update failed. <?php echo $message;   ?>  </h4>

                                    <?php  }  if(!isset($msg) && !isset($message) && !isset($suc_mesge) && !isset($fail_mesge) && !isset($update_success) && !isset($suc_msg) && (!validation_errors())) { ?>



                                        WELCOME- <?php echo $fullname ; }?> </h2>
                                <h3 class="panel-heading text-theme-colored title-border">
                                    Person Info
                                </h3>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Username',$attributes);?></label>
                                            <div class="col-md-9">
                                                <p class="form-control-static"><?php echo $username ;?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Full Name:',$attributes);?></label>
                                            <div class="col-md-9">
                                                <p class="form-control-static"><?php echo $fullname ;?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Gender:',$attributes);?></label>
                                            <div class="col-md-9">
                                                <p class="form-control-static"> <?php echo $gender ;?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Date Of Birth:',$attributes);?></label>
                                            <div class="col-md-9">
                                                <p class="form-control-static"> <?php echo $dob?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <!--/row-->
                                <!--/row-->
                                <h3 class="panel-heading text-theme-colored title-border">
                                    Contact
                                </h3>
                                <!-- new start -->
                                <div class="row ">
                                    <div class="col-md-6 ">
                                        <div class="form-group ">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Mobile Number:',$attributes);?></label>
                                            <div class="col-md-9 ">
                                                <p class="form-control-static"><?php echo $mobile ;?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 ">
                                        <div class="form-group ">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Alternate Mobile Number:',$attributes);?></label>
                                            <div class="col-md-9 ">
                                                <p class="form-control-static"> <?php echo $alter_mobile ; ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ">
                                    <div class="col-md-6 ">
                                        <div class="form-group ">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Email',$attributes);?></label>
                                            <div class="col-md-9 ">
                                                <p class="form-control-static"> <?php echo $email ; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Alternate Email:',$attributes);?></label>
                                            <div class="col-md-9">
                                                <p class="form-control-static"><?php echo $alter_email ; ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/span-->
                                </div>
                                <div class="row ">
                                    <div class="col-md-6 ">
                                        <div class="form-group ">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Temporary Address:',$attributes);?></label>
                                            <div class="col-md-9 ">
                                                <p class="form-control-static"> <?php echo $temp_address ; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 ">
                                        <div class="form-group ">
                                            <label class="control-label col-md-3">
                                                <?php    $attributes = "control-label col-md-3";?>
                                                <?php  echo form_label('Permanent Address:',$attributes);?></label>
                                            <div class="col-md-9 ">
                                                <p class="form-control-static"> <?php echo $per_address ; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h3 class="panel-heading text-theme-colored title-border ">Body Status</h3>
                            <!--/row-->
                            <div class="row ">
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Weight:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <p class="form-control-static"><?php echo $weight."Kg" ;?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Height:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <p class="form-control-static"><?php echo $height."cm" ;?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Disease/Accident:',$attributes);?></label>
                                        <div class="col-md-9">
                                            <p class="form-control-static"><?php echo $health_defect ;?></p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h3 class="panel-heading text-theme-colored title-border">Blood Status</h3>
                            <!--/row-->
                            <div class="row">
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Blood Group:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <p class="form-control-static"><?php echo $bg ;?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <?php    $attributes = "control-label col-md-3";?>
                                        <label class="control-label col-md-3">
                                            <?php  echo form_label('Last 3 months blood donate:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <p class="form-control-static"><?php echo $last_month ;?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('last donate date:',$attributes);?>
                                        </label>
                                        <div class="col-md-9 ">
                                            <p class="form-control-static"><?php echo $last_donate_date ;?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                    <div id="edit" class="tab-pane fade">

                        <?php  $attributes = array( 'autocomplete'=>'off');?>
                        <?php echo form_open('update',$attributes);?>
                        <h2 class="text-theme-colored title-border">Edit Profile</h2>
                        <div class="form-body">
                            <h3 class="panel-heading text-theme-colored title-border">
                                Person Info
                            </h3>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label col-md-3">

                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Username:',$attributes);?></label>

                                        <div class="col-md-9">

                                            <!--                                            --><?php //echo form_input(array('type'=>'text','class'=>'form-control','name'=>'username','id'=>'username','value' =>$username,'required'));?>
                                            <?php  echo form_label($username);?>
                                            <div  id="message1"></div>
                                        </div>
                                    </div>
                                </div>
                                <!--/span-->
                                <div class="col-md-6">
                                    <div class="form-group"><label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Full Name:',$attributes);?></label>
                                        <div class="col-md-9">

                                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'fullname', 'id="fullname','value' =>$fullname,'required')) ;?>

                                        </div>
                                    </div>
                                </div>
                                <!--/span-->
                            </div>
                            <!--/row-->
                            <div class="row">
                                <div class="col-md-6 mt-10">
                                    <div class="form-group">
                                        <label class="control-label col-md-3">

                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Gender:',$attributes);?></label>
                                        <div class="col-md-9">

                                            <!--                                            --><?php //$gender=array(
                                            //                                                'Male'=>'Male',
                                            //                                                'Female'=>'Female',
                                            //                                                'Other'=>'Other'
                                            //
                                            //                                            )
                                            //
                                            //                                            ?>
                                            <!--                                            --><?php
                                            //                                            echo form_dropdown( 'gender',$gender,'No','class="form-control"','id="gender"','required' );
                                            //                                            ?>
                                            <?php  echo form_label($gender);?>

                                        </div>
                                    </div>
                                </div>
                                <!--/span-->
                                <div class="col-md-6 mt-10">
                                    <div class="form-group">
                                        <label class="control-label col-md-3">

                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Date of Birth:',$attributes);?></label>
                                        <div class="col-md-9">
                                            <!--                                            --><?php //echo form_input(array('class'=>'form-control','name'=>'dob' ,'max'=>'1997-12-31','id'=>'datepicker','value' =>$dob,'required' )) ;?>
                                            <?php  echo form_label($dob);?>
                                        </div>
                                    </div>
                                </div>
                                <!--/span-->
                            </div>
                            <!--/row-->

                            <!--/span-->
                            <h3 class="panel-heading text-theme-colored title-border ">Contact</h3>
                            <!--/row-->
                            <div class="row ">
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Mobile No',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <label><?php echo $mobile ; ?></label>


                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-group "><label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Alternate Mobile No:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'alter_mobile','title'=>'Please enter if mobile only is 10 digits or lanline is 9 digits only','value' =>$alter_mobile,'required' )) ;?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ">
                                <!--    <div class="col-md-6 ">-->
                                <!--        <div class="form-group ">-->
                                <!--            <label class="control-label col-md-3">-->
                                <!--                --><?php //   $attributes = "control-label col-md-3";?>
                                <!--                --><?php // echo form_label('Email:',$attributes);?>
                                <!--            <div class="col-md-9 ">-->
                                <!--                --><?php //echo form_input(array('class'=>'form-control','name'=>'email', 'id'=>'email','pattern'=>'^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$','value' =>$email));?>
                                <!--                <div  id="message"></div>-->
                                <!--            </div>-->
                                <!--        </div>-->
                                <!--    </div>-->

                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Email:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <?php  echo form_label($email);?>
                                            <!--                                            <div  id="message"></div>-->
                                        </div>
                                    </div>
                                </div>
                                <!--/span-->
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>

                                            <?php  echo form_label('Alternate Email:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <?php echo form_input(array('class'=>'form-control','name'=>'alter_email', 'id'=>'email','value' =>$alter_email));?>

                                        </div>
                                    </div>
                                </div>
                                <!--/span-->
                            </div>
                            <div class="row ">
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Temporary Address',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'temp_address','value' => $temp_address,'required'));?>

                                        </div>
                                    </div>
                                </div>
                                <!--/span-->
                                <!--                                <div class="col-md-6 ">-->
                                <!--                                    <div class="form-group ">-->
                                <!--                                        <label class="control-label col-md-3">-->
                                <!--                                            --><?php //   $attributes = "control-label col-md-3";?>
                                <!--                                            --><?php // echo form_label('Permanent Address:',$attributes);?>
                                <!--                                        <div class="col-md-9 ">-->
                                <!--                                            --><?php //echo form_input(array('type'=>'text','class'=>'form-control','name'=>'per_address','value' =>$per_address,'required' ));?>
                                <!--<!--                                            --><?php //// echo form_label($per_address);?>
                                <!--                                        </div>-->
                                <!--                                    </div>-->
                                <!--                                </div>-->
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Permanent Address:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <?php echo form_label($per_address);?>
                                        </div>
                                    </div>
                                </div>
                                <!--/span-->
                            </div>
                            <br>
                            <!--/row-->
                            <h3 class="panel-heading text-theme-colored title-border ">Body Status</h3>
                            <!--/row-->
                            <div class="row ">
                                <div class="col-md-6">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Weight:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'weight','value' =>$weight,'required'));?>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Height:',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <?php echo form_input(array('type'=>'text','class'=>'form-control','name'=>'height','value' =>$height,'required'));?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-md-6 mt-10">
                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Any Disease cause by any virus/accident:',$attributes);?></label>
                                        <div class="col-md-9 ">

                                            <?php $health_defects=array(
                                                'Yes'=>'Yes',
                                                'No'=>'No'

                                            )

                                            ?>
                                            <?php
                                            echo form_dropdown( 'health_defects',$health_defects,'No','class="form-control"','id="health_defects"' );
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--/row-->


                        </div>
                        <div class="col-md-offset-5 col-md-9 " style="padding-bottom:85px; ">
                            <?php echo form_submit(array('name'=>'btnUpdate','content'=>'Update','value'=>'Update','class'=>'btn  btn-lg btn-theme-colored btn-circled','width'=>'100%')); ?>

                        </div>
                        <br></form>
                    </div>





                    <!--Third-->
                    <div id="blood" class="tab-pane fade">

                        <?php  $attributes = array( 'autocomplete'=>'off');?>
                        <?php echo form_open('updateBlood',$attributes);?>
                        <h2 class="text-theme-colored title-border">Blood Status</h2>
                        <div class="form-body">

                            <div class="row ">
                                <div class="col-md-6 ">

                                    <div class="form-group ">
                                        <label class="control-label col-md-3">



                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Blood Group:',$attributes);?></label>
                                        <div class="col-md-9 ">

                                            <!--                                            --><?php //echo form_input(array('type'=>'text','class'=>'form-control','name'=>'bloodgroup','required' , 'id'=>'bloodgroup','value' =>$bloodgroup )) ;?>
                                            <?php  echo form_label($bg);?>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-md-6 ">


                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Last 3 months blood donate',$attributes);?></label>
                                        <div class="col-md-9 ">
                                            <?php $last_month=array(
                                                'Yes'=>'Yes',
                                                'No'=>'No'

                                            )

                                            ?>
                                            <?php
                                            echo form_dropdown( 'last_month',$last_month,'No','class="form-control"','id="last_month"','required');
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 ">


                                    <div class="form-group ">
                                        <label class="control-label col-md-3">
                                            <?php    $attributes = "control-label col-md-3";?>
                                            <?php  echo form_label('Last donate date',$attributes);?></label>
                                        <div class="col-md-9 ">

                                            <?php echo form_input(array('class'=>'form-control','name'=>'last_donate_date','required' , 'id'=>'last_donate','value' =>$last_donate_date )) ;?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <br>
                        <div class="col-md-offset-5 col-md-9 " style="padding-bottom:85px; ">
                            <?php echo form_submit(array('name'=>'btnUpdate','content'=>'Update','value'=>'Update','class'=>'btn btn-lg btn-theme-colored btn-circled','width'=>'100%')); ?>

                        </div>
                        <br>
                        </form>
                    </div>
                    <!--fourth menu password starts from here-->
                    <div id="password" class="tab-pane fade">
                        <div class="container">
                            <h3 class=" text-theme-colored title-border ">Change Password</h3>
                            <form class="form-horizontal " action="change_password" method="POST">
                                <div class="col-lg-2 col-lg-offset-1 ">
                                    <div class="form-group mt-5">
                                        <?php  echo form_label('Old Password:');?></label>
                                    </div>
                                </div>
                                <div class="col-lg-7" >
                                    <div class="input-group " style="padding-bottom:5px; ">
<span class="input-group-addon ">
<i class="fa fa-lock" aria-hidden="true "></i></span>
                                        <?php echo form_input(array('type'=>'password','class'=>'form-control','name'=>'old_password','autofocus','required' ));?>

                                    </div>
                                </div>
                                <br/>
                                <!--  <div class="col-lg-4 "> -->
                                <div class="col-lg-2 col-lg-offset-1 ">
                                    <div class="form-group ">
                                        <?php  echo form_label('New Password:');?></label>

                                    </div>
                                </div>
                                <div class="col-lg-7">
                                    <div class="input-group " style="padding-bottom:5px; ">
                                        <span class="input-group-addon "><i class="fa fa-lock " aria-hidden="true "></i></span>
                                        <?php echo form_input(array('type'=>'password','class'=>'form-control','name'=>'new_password','autofocus' ,'required'));?>

                                    </div>
                                </div>
                                <br/>
                                <div class="col-lg-2 col-lg-offset-1 ">
                                    <div class="form-group ">

                                        <?php  echo form_label('Confirm New Password:');?></label>

                                    </div>
                                </div>
                                <div class="col-lg-7 ">
                                    <div class="input-group " style="padding-bottom:5px; ">
                                        <span class="input-group-addon "><i class="fa fa-lock " aria-hidden="true "></i></span>
                                        <!--                                    <input type="password" name="confirm_password"  id="c_password " class="form-control "/>-->
                                        <?php echo form_input(array('type'=>'password','class'=>'form-control','name'=>'confirm_password','autofocus','required' ));?>

                                    </div>
                                </div>
                                <div class="col-md-offset-5 col-md-9 " style="margin-top:20px; ">
                                    <button type="submit" class="btn btn-lg btn-theme-colored btn-circled" name="btnUpdate" style="margin-bottom:20px;">Update</button>
                                </div>
                        </div>
                        </form>
                    </div>



                </div>
            </div>

        </div>
        <script type="text/javascript">
        // Password validation with confirm password

        function checkPass() {
//Store the password field objects into variables ...
            var pass1 = document.getElementById('password');
            var pass2 = document.getElementById('rpassword');
//Store the Confimation Message Object ...
            var message = document.getElementById('confirmMessage');
//Set the colors we will be using ...
            var goodColor = "#66cc66";
            var badColor = "#ff6666";
//Compare the values in the password field
//and the confirmation field
            if (password.value == rpassword.value) {
//The passwords match.
//Set the color to the good color and inform
//the user that they have entered the correct password
                pass2.style.backgroundColor = goodColor;
                message.style.color = goodColor;
                message.innerHTML = "Passwords Match!"
            } else {
//The passwords do not match.
//Set the color to the bad color and
//notify the user.
                pass2.style.backgroundColor = badColor;
                message.style.color = badColor;
                message.innerHTML = "Passwords Do Not Match!"
            }
        }
    </script>


    <script type="text/javascript">
        $(document).ready(function(){
            $('#username').keyup(function(){
                var user_name = $(this).val(); // Get username textbox using $(this)
                var Result = $('#message1'); // Get ID of the result DIV where we display the results
                if(user_name.length > 2) { // if greater than 2 (minimum 3)
                    Result.html('Loading...'); // you can use loading animation here
                    var dataPass = 'action=availability&user_name='+user_name;
                    $.ajax({ // Send the username val to available.php
                        type : 'POST',
                        data : dataPass,
                        url  : 'check_users',
                        success: function(responseText){ // Get the result
                            if(responseText == 0){
                                Result.html('<span class="success">Available</span>');
                            }
                            else if(responseText > 0){
                                Result.html('<span class="error">Taken</span>');
                            }
                            else{
                                alert('Problem with sql query');
                            }
                        }
                    });
                } else {
                    Result.html('Enter valid name');
                }
//                                                if(username.length == 0) {
//                                                    Result.html('');
//                                                }
            });
        });
    </script>
   <script src="<?php echo base_url();?>js/js/jquery.ui.datepicker.min.js">
    </script>
    <script type="<?php echo base_url(); ?>js/parsley.min.js"></script>
    <script type="text/javascript">
        $( function() {
            $("#datepicker").datepicker({
                minDate: new Date(1940, 0, 1),
                maxDate: new Date(1997, 0, 1),
                dateFormat: 'yy-mm-dd',
                changeMonth: true,
                changeYear: true
            });
        });
    </script>
    <script type="text/javascript">

        $(document).ready(function(){
            $('#email').keyup(function(){
                var useremail = $(this).val(); // Get username textbox using $(this)
                var Result = $('#message'); // Get ID of the result DIV where we display the results
                if(useremail.length > 2) { // if greater than 2 (minimum 3)
                    Result.html('Loading...'); // you can use loading animation here
                    var dataPass = 'action=availability&useremail='+useremail;
                    $.ajax({ // Send the username val to available.php
                        type : 'POST',
                        data : dataPass,
                        url  : 'check_emails',
                        success: function(responseText){ // Get the result
//                                                            alert(responseText);
                            if(responseText == 0){
                                Result.html('<span class="success">Available</span>');
                            }
                            else if(responseText > 0){
                                Result.html('<span class="error">Taken</span>');
                            }
                            else{
                                alert('Problem with sql query');
                            }
                        }
                    });
                } else {
                    Result.html('Enter valid email address');
                }
//                                                if(username.length == 0) {
//                                                    Result.html('');
//                                                }
            });
        });
    </script>

        <br> <br> <br>
        <!-- end main-content -->
        <!-- Footer -->
      