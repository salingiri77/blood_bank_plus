<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
    <meta property="og:url" content="http://www.bloodbankplus.org" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="BloodBank+ | Give Hope. Give Blood. Give Life." />
    <meta property="og:description" content="Blood Bank+ is a platform that connects eligible & willing blood donors to people who need blood. With just few steps, you are connected with the perfect person who has and wants to donate the blood."
    />
    <meta property="og:image" content="http://www.bloodbankplus.org/img/logo-fb.png" />
    <!-- Page Title -->
    <title>
        BloodBankPlus | Solution for Blood Emergency
    </title>
      <link rel="stylesheet" href="<?php echo base_url();?>public/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/css/main.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/css/jquery.ui.core.css">
    <!-- <link rel="stylesheet" href="css/css/jquery.ui.datepicker.css"> -->
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/css/jquery.ui.theme.css">
    <link href="<?php echo base_url(); ?>public/css/termscustom.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/css/chosen.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/css/table_ui.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/css/themes/smoothness/jquery-ui-1.8.4.custom.css">

    <link rel="stylesheet" href="<?php echo base_url();?>public/css/css/jquery.dataTables.css">
    <!--Favicon and Touch Icons-->
    <link href="<?php echo base_url(); ?>public/images/bloodbankplus.ico" rel="shortcut icon" sizes="32*32">
    <!-- Favicon and Touch Icons -->
    <!-- <link href="images/favicon.png" rel="shortcut icon" type="image/png">
       <link href="images/apple-touch-icon.png" rel="apple-touch-icon">
       <link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
       <link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
       <link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144"> -->
    <!-- Stylesheet -->
    <link href="<?php echo base_url(); ?>public/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>public/css/jquery-ui.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>public/css/animate.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>public/css/css-plugin-collections.css" rel="stylesheet"/>
    <link href="<?php echo base_url(); ?>public/css/privacycustom.css" rel="stylesheet"/>
    <!-- this css help footer slider image -->
    <link href="<?php echo base_url(); ?>public/css/window.slider.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>public/css/slick.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>public/css/slick-theme.css" rel="stylesheet">
    <!-- CSS | menuzord megamenu skins -->
    <link id="menuzord-menu-skins" href="<?php echo base_url(); ?>public/css/menuzord-skins/menuzord-boxed.css" rel="stylesheet"/>
    <!-- CSS | Main style file -->
    <link href="<?php echo base_url(); ?>public/css/style-main.css" rel="stylesheet" type="text/css">
    <!-- CSS | Preloader Styles -->
    <link href="<?php echo base_url(); ?>public/css/preloader.css" rel="stylesheet" type="text/css">
    <!-- CSS | Custom Margin Padding Collection -->
    <link href="<?php echo base_url(); ?>public/css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
    <!-- CSS | Responsive media queries -->
    <link href="<?php echo base_url(); ?>public/css/responsive.css" rel="stylesheet" type="text/css">
    <!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
    <!-- This style css use slider logo-->
    <link href="<?php echo base_url(); ?>public/css/style.css" rel="stylesheet" type="text/css">
    <!-- Revolution Slider 5.x CSS settings -->
        <link href="<?php echo base_url();?>public/css/formcss.css" type="text/css" rel="stylesheet">

    <link href="<?php echo base_url();?>public/css/customcss.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url(); ?>public/css/privacycustom.css" rel="stylesheet" type="text/css">


    <link href="<?php echo base_url(); ?>public/js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>public/js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>public/js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>
    <!-- CSS | Theme Color -->
    <link href="<?php echo base_url(); ?>public/css/colors/theme-skin-red.css" rel="stylesheet" type="text/css">
    <!-- external javascripts -->
    <script src="<?php echo base_url(); ?>public/js/jquery-2.2.0.min.js"></script>
    <script src="<?php echo base_url(); ?>public/js/jquery-ui.min.js"></script>
    <script src="<?php echo base_url("public/js/bootstrap.min.js"); ?>"></script>
    <!-- This script help to footer slider-->
    <!-- JS | jquery plugin collection for this theme -->
    <script src="<?php echo base_url(); ?>public/js/jquery-plugin-collection.js"></script>
    <!-- Revolution Slider 5.x SCRIPTS -->
    <script src="<?php echo base_url(); ?>public/js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
    <script src="<?php echo base_url(); ?>public/js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- slide image css-->
    <style type="text/css">
        /*  html, body {
            margin: 0;
            padding: 0;
          }*/
        /*
            * {
              box-sizing: border-box;
            }
        */
        .slider {
            width: 50%;
            margin: 150px auto;
        }
        /*
            .slick-slide {
              margin: 0px 20px;
            }*/

        .slick-slide img {
            width: 130px;
            height: 100px;
        }

        .slick-prev:before,
        .slick-next:before {
            color: black;
        }
    </style>
</head>

<body class="has-side-panel side-panel-right fullwidth-page side-push-panel">

<div class="body-overlay">
</div>
<div id="wrapper" class="clearfix">


    <!-- Header -->
    <div style="text-align:center; background:#bce8f1; color:#db1033;">

        <?php if(isset($message)){ ?>
            <i class="fa fa-check text-white">
            </i>
            <?php echo $message;
        }  ?>

         <?php if(isset($email)){ ?>
            <i class="fa fa-check text-white">
            </i>
            <?php echo $email;
        }  ?>


        <?php if(isset($messages)){ ?>
            <i class="fa fa-check text-white">
            </i>
            <?php echo $messages;
        }  ?>

        <?php if(isset($message2)){ ?>
            <i class="fa fa-check text-white">
            </i>
            <?php echo $message2;
        }  ?>
    </div>
    <header id="header" class="header">
        <div class="header-top bg-theme-colored sm-text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="widget no-border m-0">
                            <ul class="social-icons icon-dark icon-theme-colored icon-sm sm-text-center">
                                <li>
                                    <a href="https://www.facebook.com/BloodBankPlus"><i class="fa fa-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.twitter.com/BloodbankPlus"><i class="fa fa-twitter"></i></a>
                                </li>
                                <!-- <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                   <li><a href="#"><i class="fa fa-linkedin"></i></a></li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="widget no-border m-0">
                            <ul class="list-inline pull-right flip sm-pull-none sm-text-center mt-5">
                                <li class="m-0 pl-10 pr-10">
                                    <i class="fa fa-phone text-white">
                                    </i>
                                    <a class="text-white">9860484858, +97714786103</a>
                                </li>
                                <li class="m-0 pl-10 pr-10">
                                    <i class="fa fa-envelope-o text-white">
                                    </i>
                                    <a class="text-white" href="mailto:help@bloodbankplus.org">help@bloodbankplus.org</a>
                                </li>
                                <li class="sm-display-block mt-sm-10 mb-sm-10">
                                    <!-- Modal: Appointment Starts -->
                                    <?php if(!$this->session->has_userdata('logged_in')){ ?>
                                        <a class="bg-light p-5 text-theme-colored font-11 pl-10 pr-10" data-target="#BSParentModal" href="<?php echo base_url('login_user'); ?>">Login</a>
                                    <?php  } else { ?>
                                        <a class="bg-light p-5 text-theme-colored font-11 pl-10 pr-10" data-target="#BSParentModal" href="view_profile">My Profile</a>
                                        <a class="bg-light p-5 text-theme-colored font-11 pl-10 pr-10" data-target="#BSParentModal" href="<?php echo base_url('logout'); ?>">Logout</a>
                                    <?php } if(!$this->session->has_userdata('logged_in')){
                                        ?>
                                        <a class="bg-light p-5 text-theme-colored font-11 pl-10 pr-10" data-target="#BSParentModal" href="<?php echo base_url('register'); ?>">Register</a>
                                    <?php  } ?>
                                    <!-- Modal: Appointment End -->
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-nav">
            <div class="header-nav-wrapper navbar-scrolltofixed bg-lightest" style="z-index: auto; position: static; top: auto;">
                <div class="container">
                    <nav id="menuzord-right" class="menuzord blue bg-lightest menuzord-responsive">
                        <!-- <a href="javascript:void(0)" class="showhide" style="display: none;"><em></em><em></em><em></em></a> -->
                        <a class="menuzord-brand pull-left flip" href="<?php echo base_url(); ?>">
                            <img src="<?php echo base_url(); ?>public/images/logo/BBP.png" alt="BloodBankPlus">
                        </a>
                        <!-- <div id="side-panel-trigger" class="side-panel-trigger"><a href="#"><i class="fa fa-bars font-24 text-gray"></i></a></div> -->
                        <!--                        <ul class="menuzord-menu pull-right menuzord-right menuzord-indented scrollable" style="max-height: 400px;">-->
                        <!--                            <li class="active">-->
                        <!--                                <a href="--><?php //echo base_url(); ?><!--"><i class="fa fa-home fa-2x"></i>HOME</a>-->
                        <!--                            </li>-->
                        <!--                            <li>-->
                        <!--                                <a href="--><?php //echo base_url(); ?><!--#about">ABOUT</a>-->
                        <!--                            </li>-->
                        <!--                            <li>-->
                        <!--                                <a href="--><?php //echo base_url(); ?><!--#how">HOW WE WORK</a>-->
                        <!--                            </li>-->
                        <!--                            <li>-->
                        <!--                                <a href="--><?php //echo base_url(); ?><!--#partners">PARTNERS</a>-->
                        <!--                            </li>-->
                        <!--                            <li>-->
                        <!--                                <a href="faq">FAQ</a>-->
                        <!--                            </li>-->
                        <!--                        </ul>-->
                        <ul class="menuzord-menu menuzord-right menuzord-indented scrollable" style="max-height: 400px;">
                       <?php if(isset($result)){  ?>
                   
                            <li class="onepage-nav"><a href="#home"><i class="fa fa-home fa-2x"></i>HOME</a> </li>
                            <li class="onepage-nav"><a href="#about">ABOUT</a></li>
                            <li class="onepage-nav"><a href="#how">HOW WE WORK</a></li>
                            <li class="onepage-nav"><a href="#partners">PARTNERS</a></li>
                            <li><?php echo anchor('faq', 'FAQ'); ?></li>
                            <?php } else { ?>
                            <li class=""><a href="<?php echo base_url();  ?>#home"><i class="fa fa-home fa-2x"></i>HOME</a> </li>
                            <li class=""><a href="<?php echo base_url();  ?>#about">ABOUT</a></li>
                            <li class=""><a href="<?php echo base_url();  ?>#how">HOW WE WORK</a></li>
                            <li class=""><a href="<?php echo base_url();  ?>#partners">PARTNERS</a></li>
                            <?php if (isset($results)){ ?><li class="active" > <?php } else{ ?> <li class="" ><?php } ?> <a href="faq">FAQ</a></li>
                            <?php  } ?>
                            <!-- <li class="scrollable-fix"></li> -->
                        </ul>
                    </nav>
                </div>
            </div>
            <div style="display: none; width: 1349px; height: 70px; float: none;">
            </div>
        </div>
    </header>