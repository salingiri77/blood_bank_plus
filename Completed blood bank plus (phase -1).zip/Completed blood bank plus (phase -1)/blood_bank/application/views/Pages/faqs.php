
	<!-- Start main-content -->
	<div class="main-content">
		<!-- Section: inner-header -->
		<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="<?php echo base_url(); ?>public/images/faq2.png">
			<div class="container pt-100 pb-50">
				<!-- Section Content -->
				<div class="section-content pt-100">
					<div class="row">
					</div>
				</div>
			</div>
		</section>
		<section class="position-inherit">
			<div class="container">
				<div class="row">
					<div class="col-md-3 scrolltofixed-container">
						<div class="list-group scrolltofixed z-index-0 mb-60 .visible-xs-12" style="color:black;">
							<a href="#section-one" class="list-group-item smooth-scroll-to-target onepage-nav"><b>Q. How does the blood donation process work?</b></a>
							<a href="#section-two" class="list-group-item smooth-scroll-to-target onepage-nav"><b>Q. Will it hurt when you insert the needle?</b></a>
							<a href="#section-three" class="list-group-item smooth-scroll-to-target "><b>Q. What should I do after donating blood?</b></a>
							<a href="#section-four" class="list-group-item smooth-scroll-to-target onepage-nav"><b>Q.How long does a blood donation take?</b></a>
							<a href="#section-five" class="list-group-item smooth-scroll-to-target onepage-nav "><b>Q. How long will it take to replenish the pint of blood I donate?</b></a>
							<a href="#section-six" class="list-group-item smooth-scroll-to-target onepage-nav"><b>Q.What are the criteria for blood donation?</b></a>
							<a href="#section-seven" class="list-group-item smooth-scroll-to-target onepage-nav"><b>Q.How often can I donate blood?</b></a>
							<a href="#section-eight" class="list-group-item smooth-scroll-to-target onepage-nav"><b>Q.Who should not donate blood?</b></a>
							<a href="#section-nine" class="list-group-item smooth-scroll-to-target onepage-nav"><b>Q.Why donate blood?</b></a>
							<a href="#section-ten" class="list-group-item smooth-scroll-to-target onepage-nav"><b>Q.Is it safe to donate blood?</b></a>
						</div>
					</div>
					<div class="col-md-9">
						<div id="section-one" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title onepage-nav">Q. How does the blood donation process work?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
										Donating blood is a simple thing to do, but can make a big difference in the lives of others. The donation process from the time you arrive until the time you leave takes about an hour. The donation itself is only about 8-10 minutes on average. The steps in the process are:
									</p>
									<p>
										<b>
											Registration
										</b>
									</p>
									<p>
										You will complete donor registration, which includes information such as your name, address, phone number, and donor identification number (if you have one).
									</p>
									<p>
										You will be asked to show a donor card, driver's license or two other forms of ID.
									</p>
									<p>
										<b>
											Health History and Mini Physical
										</b>
									</p>
									<p>
										You will answer some questions during a private and confidential interview about your health history and the places you have traveled.
									</p>
									<p>
										You will have your temperature, hemoglobin, blood pressure and pulse checked.
									</p>
									<p>
										<b>
											Donation
										</b>
									</p>
									</p>
								</div>
							</div>
						</div>
						<div id="section-two" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q. Will it hurt when you insert the needle?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
										Only for a moment. Pinch the fleshy, soft underside of your arm. That pinch is similar to what you will feel when the needle is inserted.
									</p>
								</div>
							</div>
						</div>

						<div id="section-three" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q. What should I do after donating blood?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
									<p><b>
											After you give blood:</b>
									</p>
									<ul>
										<li>
											<div>
												<p><b>
														Take the following precautions</b>
												</p>
											</div>
											<div>
												<p>
                                                        <span class="icon_stop"><b></b>
                                                        </span>

													Drink an extra four glasses (eight ounces each) of non-alcoholic liquids.</p>
											</div>
											<div>
												<p>
                                                        <span class="icon_stop">
                                                        </span>

													Keep your bandage on and dry for the next five hours, and do not do heavy exercising or lifting.</p>
											</div>
											<div>
												<p>
                                                            <span class="icon_stop">
                                                            </span>

													If the needle site starts to bleed, raise your arm straight up and press on the site until the bleeding stops.</p>
											</div>
											<div>
												<p>
                                                            <span class="icon_stop">
                                                            </span>

													Because you could experience dizziness or loss of strength, use caution if you plan to do anything that could put you or others at risk of harm. For any hazardous occupation or hobby, follow applicable safety recommendations regarding your return to these activities following a blood donation.</p>
											</div>
											<div>
												<p>
                                                        <span class="icon_stop">
                                                        </span>

													Eat healthy meals and consider adding iron-rich foods to your regular diet, or discuss taking an iron supplement with your health care provider, to replace the iron lost with blood donation.</p>

											</div>
										</li>
										<li>
											<div>
												<p>
													<strong><b>
															If you get a bruise
													</strong></b></p>
												<p>
													Apply ice to the area intermittently for 10-15 minutes during the first 24 hours. Thereafter, apply warm, moist heat to the area intermittently for 10-15 minutes. A rainbow of colors may occur for about 10 days.</p>

											</div>
										</li>
										<li>
											<div>
												<b><p>
														If you get dizzy or lightheaded</b>
												</p>
												<span><p>
                                                            Stop what you are doing, lie down, and raise your feet until the feeling passes and you feel well enough to safely resume activities.</p>
                                                        </span>
											</div>
										</li>
										<li>
											<p>
												<strong><b>
														And remember to enjoy the feeling of knowing you have helped save lives!</b>
												</strong></p>
										</li>
										<li>
											<p>
												<strong><b>
														Schedule your next appointment</b>
												</strong></p>
										</li>
									</ul>
									</p>
								</div>
							</div>
						</div>
						<div id="section-four" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q.How long does a blood donation take?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
										The entire process takes about one hour and 15 minutes; the actual donation of a pint of whole blood unit takes eight to 10 minutes. However, the time varies slightly with each person depending on several factors including the donor's health history and attendance at the blood drive.
									</p>
								</div>
							</div>
						</div>
						<div id="section-five" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q. How long will it take to replenish the pint of blood I donate?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
										The plasma from your donation is replaced within about 24 hours. Red cells need about four to six weeks for complete replacement. That's why at least eight weeks are required between whole blood donations.
									</p>
								</div>
							</div>
						</div>
						<div id="section-six" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q. What are the criteria for blood donation?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
									<p>
										<b>
											To be eligible to donate blood:
										</b>
									</p>
									<p>
										<span class="icon_stop"></span> A person must be in good health and generally must be at least 16 years of age (or in accordance with applicable state law).
									</p>
									<p> <span class="icon_stop"></span>Minimum weight requirements may vary among facilities, but generally, donors must weigh at least 110 pounds.
									</p>
									<p> <span class="icon_stop"> </span> All donors must pass the physical and health history examinations prior to donation.
									</p>
									<p><span class="icon_stop"> </span> Individuals may be temporarily ineligible to donate due to mild illnesses (colds or flu), unregulated hypertension, and diabetes and anemia.
									</p>
									<p><span class="icon_stop"></span> The donor's body replenishes the fluid lost from donation within 24 hours. It may take up to two weeks to replace the lost red blood cells. Whole blood can be donated once every eight weeks (56 days). Two units of red blood cells can be donated at one time, using a process known as red cell apheresis. This type of donation can be made every 16 weeks.
									</p>
									</p>
								</div>
							</div>
						</div>
						<div id="section-seven" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q.How often can I donate blood?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
										You must wait at least eight weeks (56 days) between donations of whole blood and 16 weeks (112 days) between Power Red donations. Platelet apheresis donors may give every 7 days up to 24 times per year. Regulations are different for those giving blood for themselves (autologous donors)
									</p>
								</div>
							</div>
						</div>
						<div id="section-eight" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q.Who should not donate blood?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
									<p><span class="icon_stop"></span> Anyone who has ever used needles to take drugs, steroids, or any substance not prescribed by a doctor.
									</p>
									<p><span class="icon_stop"></span> Men who have had sexual contact with other men in the past 12 months.
									</p>
									<p><span class="icon_stop"></span> Anyone with a positive test for HIV (AIDS virus).
									</p>
									<p><span class="icon_stop"></span> Men and women who have ever engaged in sex for money or drugs.
									</p>
									<p><span class="icon_stop"></span> Anyone who has had hepatitis since his or her eleventh birthday.
									</p>
									<p><span class="icon_stop"></span> Anyone who has had babesiosis or Chagas disease.
									</p>
									<p><span class="icon_stop"></span> Anyone who has taken Tegison for psoriasis.
									</p>
									<p><span class="icon_stop"></span> Anyone who has risk factors for Creutzfeldt-Jakob disease (CJD) or who has a blood relative with CJD.
									</p>
									<p><span class="icon_stop"></span> Anyone who has risk factors for vCJD, including:
									</p>
									<p><span class="icon_stop"></span> Anyone who spent three months or more in the United Kingdom from 1980 through 1996.
									</p>
									<p><span class="icon_stop"></span> Anyone who received a blood transfusion in the United Kingdom or France from 1980 to the present.
									</p>
									<p><span class="icon_stop"></span> Anyone who has spent five years in Europe from 1980 to the present.
									</p>
									</p>
								</div>
							</div>
						</div>
						<div id="section-nine" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q.Why donate blood?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
										You don’t need a special reason to give blood. Some know that a family member or a friend might need blood some day. Some believe it is the right thing we do. Whatever your reason, the need is constant and your contribution is important for a healthy and reliable blood supply. And you’ll feel good knowing you've helped change a life.
									</p>
								</div>
							</div>
						</div>

						<div id="section-ten" class="mb-50">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<h3 class="panel-title">Q.Is it safe to give blood?</h3>
								</div>
								<div class="panel-body">
									<p class="mb-20">
										Donating blood is a safe process. Each donor’s blood is collected through a new, sterile needle that is used once and then discarded. Although most people feel fine after donating blood, a small number of people may feel lightheaded or dizzy, have an upset stomach or experience a bruise or pain where the needle was inserted. Extremely rarely, loss of consciousness, nerve damage or artery damage occur.
									</p>
								</div>
							</div>
						</div>
					</div>
		</section>
	</div>
	<!-- end main-content -->

	<!-- Footer -->
	