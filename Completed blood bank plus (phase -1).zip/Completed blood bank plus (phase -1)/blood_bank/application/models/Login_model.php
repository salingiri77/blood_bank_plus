<?php
class Login_model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }


    public function get_password($username){
        $condition = "username =" . "'" . $username . "'";
        $this->db->SELECT ('password');
        $this->db->FROM('user_account');
//        $this->db->join('mobile_verification','user_account.user_id =mobile_verification.user_id ');
//        $this->db->where('is_verified',1);
        $this->db->where($condition);
        $query = $this->db->get();
        return $query->row();

    }

    public function check_mobile_verification($userid){
        $this->db->select('is_verified');

        $this->db->where('user_id',$userid);

        $this->db->FROM('mobile_verification');

        $query = $this->db->get();

        return $query->row();

   }

    public function user_id($username){

       $this->db->select('user_id');

       $this->db->where('username',$username);

       $this->db->FROM('user_account');

       $query = $this->db->get();

       return $query->row();

        }

       public function check_mobile_verified_user($user_id){

       $this->db->select('is_verified');

       $this->db->where('user_id',$user_id);

       $this->db->FROM('mobile_verification');

       $query = $this->db->get();

       return $query->row();    }


    public function get_user($username){

        $condition = "username =" . "'" . $username . "'";
        $this->db->SELECT ('*');
        $this->db->FROM('user_account');
        $this->db->where($condition);
        $query =  $this->db->get();
        $row = $query->row();
        return $row;




//        $condition = "username =" . "'" . $username . "' AND " . "password =" . "'" . $password . "'";
//        $this->db->SELECT ('*');
//        $this->db->FROM('user_account');
//        $this->db->where($condition);
//        $query = $this->db->get();
//        //echo $condition;
//        $row = $query->row();
//        return $row;


//        if($query->num_rows() == 1)
//        {
//            // redirect('home/index');
//
//            return true;
//        }else {
//            return false;
//        }
    }


    public function check_username($username){

        $this->db->SELECT ('*');
        $this->db->FROM('user_account');
        $this->db->where('username',$username);

        $query = $this->db->get();
        //echo $condition;
        $row = $query->row();
        return $row;






    }


}
?>
