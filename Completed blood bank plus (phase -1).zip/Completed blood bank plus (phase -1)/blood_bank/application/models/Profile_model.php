<?php

class Profile_model extends CI_Model 
{

 function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }





    public function select_profile_details($userid)
    {
        $this->db->select('email,temp_address,height,weight');
        $this->db->from('profile');
        $this->db->where('user_id', $userid);
        $query = $this->db->get();
        return $query->row();
    }

    public function update_profile_detail($profile,$userid){
        $this->db->where('user_id', $userid);
        $this->db->update('profile', $profile);
        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }
    }

    function update_check_email($email,$userid){
        $this->db->select('*')->from('profile');
        $this->db->where('email', $email);
        $this->db->where('user_id !=',$userid);

        $query = $this->db->get();

        if($query->num_rows() > 0 ){
            return true;
        }

        else{
            return false;
        }


    }


    function user_check_email($email){
        $this->db->select('*')->from('profile');
        $this->db->where('email', $email);

        $query = $this->db->get();

        if($query->num_rows() > 0 ){
            return true;
        }

        else{
            return false;
        }


    }


    public function email($user_id){
        $this->db->select('email');
        $this->db->from('profile');
        $this->db->where('user_id',$user_id);
        $query = $this->db->get();
        return $query->row();
    }


    function form_insert($data){


        $this->db->insert('profile', $data);
        $id  = $this->db->insert_id();
        return $id;

    }

    function select_email(){

        $query = $this->db->get_where('profile', ['email' => $this->input->post('useremail')]);
        echo $query->num_rows();



    }


    public function update_profile($data,$email){
        $this->db->where('email', $email);
        $this->db->update('profile', $data);

        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }

    }

    public function check_emailMobile($email,$mobile){

        $this->db->join('mobile_verification','profile.user_id =mobile_verification.user_id ');
        $this->db->where('email', $email);
        $this->db->where('mobile', $mobile);
        $this->db->from('profile');
        $num_res = $this->db->count_all_results();
        return $num_res;
    }



    public function does_email_exist($email) {
        $this->db->where('email', $email);
        $this->db->from('profile');
        $num_res = $this->db->count_all_results();
        if ($num_res == 1) {
            return TRUE;
        } else {
            return FALSE;
        }
    }


    public function does_code_match($code, $email) {
        $this->db->where('email', $email);
        $this->db->where('forgot_password', $code);
        $this->db->from('profile');
        $num_res = $this->db->count_all_results();

        if ($num_res == 1) {
            return TRUE;
        } else {
            return FALSE;
        }
    }


    public function select_user_id($email) {
        $this->db->select('user_id');
        $this->db->where('email', $email);
        $this->db->from('profile');
        $query = $this->db->get();
        $user_id= $query->row();
        return $user_id;

//        $num_res = $this->db->count_all_results();
//
//        if ($num_res == 1) {
//            return TRUE;
//        } else {
//            return FALSE;
//        }
    }





    function select_emails($user_id){
        $this->db->where('user_id !=',$user_id);
        $query = $this->db->get_where('profile', ['email' => $this->input->post('useremail')]);

        echo $query->num_rows();

    }
}