<?php

class Mobileverification_model extends CI_Model 
{

     function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }




    function value_insert($user_verify){

        $this->db->insert('mobile_verification', $user_verify);
        return $user_verify;
    }

    function value_update($user_verify,$user_id){
        $this->db->where('user_id', $user_id);
        $this->db->update('mobile_verification', $user_verify);
        if($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }
    }


}
