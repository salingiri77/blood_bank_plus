
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class myclass extends CI_Controller {

    function __Construct(){
        parent::__Construct ();

        $this->load->library('myclass');


    }


    public function test(){
        echo "my test";
    }
}

?>