<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cognalys extends CI_Controller {


    protected $accessToken = 'd1a71e3cb2139319fab42cff34bc9a8931d0fb32';
    protected $appId = 'f6b5e9b6e09642089bd87cf';

    function __Construct(){
        parent::__Construct ();
        $this->load->database();
        $this->load->model('login_model');
        $this->load->model('cognalys_model');
        $this->load->model('mobileverification_model');
        $this->load->model('useraccount_model'); 
        $this->load->model('userdetail_model'); 
        $this->load->model('userverification_model'); 
        $this->load->model('profile_model');  
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');

//        $this->output->enable_profiler(TRUE);

    }


   function rsg($length = 80, $complexity = 2) {
        //'complexity' subsets of characters
        $charSubSets = array(
            'abcdefghijklmnopqrstuvwxyz',
            'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
            '0123456789',
            '!@#$%^&*()_+{}|:">?<[]\\\';,.`~',
            'µñ©æáßðøäåé®þüúíóö'
        );

        $chars = '';

        //concact each subset until complexity reached onto empty string
        for ($i = 0; $i < $complexity; $i++)
            $chars .= $charSubSets[$i];

        //make string from the combined subsets.
        $chars = str_split($chars);
        //define length of array for mt_rand limit
        $charCount = (count($chars) - 1);
        //create string to return
        $string = '';
        //idk why I used a while but it won't really hurt you when the string is less than 100000 chars long ;)
        $i = 0;
        while ($i < $length) {
            $randomNumber = mt_rand(0, $charCount); //generate number within array index range
            $string .= $chars[$randomNumber]; //get that character out of the array
            $i++; //increment counter
        }

        return $string; //return string created from random characters
    }


    public function email_verification(){

        if(!$this->session->has_userdata('logged_in')){
            $session_data = $this->session->userdata('register');
            $email=$session_data['user_id'];

        }
        else{
            $session_data = $this->session->userdata('logged_in');
            $user_id=$session_data['user_id'];
            $emails=$this->profile_model->email($user_id);
            $email=$emails->email;

        }
        $to = $email;
        $randomly_generated_code =$this->rsg();
        $url= base_url() . 'loginn?code=';
        $link=$url .$randomly_generated_code;
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";

        $this->load->library('email',array('mailtype'=>'html'));
        $this->email->initialize(array(

            'protocol' => 'smtp',
            'smtp_host' => 'smtp.sendgrid.net',
            'smtp_user' => 'noreply@technorio.com',
            'smtp_pass' => 'N0replyTec#n0ri0',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n"

            // 'protocol' => 'smtp',
            // 'smtp_host' => 'smtp.mailtrap.io',
            // 'smtp_user' => '91d77d7198b1f2',
            // 'smtp_pass' => '4407fa8c2e4e78',
            // 'smtp_port' => 2525,
            // 'crlf' => "\r\n",
            // 'newline' => "\r\n"

            // 'protocol' => 'smtp',
            // 'smtp_host' => 'smtp.mailtrap.io',
            // 'smtp_user' => '91d77d7198b1f2',
            // 'smtp_pass' => '4407fa8c2e4e78',
            // 'smtp_port' => 2525,
            // 'crlf' => "\r\n",
            // 'newline' => "\r\n"
        ));$this->email->from('noreply@bloodbankplus.org', 'BloodBank+');
        $this->email->to($to);
        //$this->email->cc('another@another-example.com');
        //$this->email->bcc('them@their-example.com');
        $this->email->subject('Email Verification');
        $this->email->message('Please click on the link to verify your email '. "<html><a href=$link>Click Here</a></html>");
        $this->email->send();

//        echo $this->email->print_debugger();


        $user_verify_data =  array(
            'user_id' => $this->session->user_id ,
            'email_verified' => '0',
            'use_status' => '0',
            'email_code' => $randomly_generated_code


        );
  
        $this->userverification_model->email_verify($user_verify_data);


    } 


        public function user_check()

    {   
        
         $messages['miscall']=$this->session->flashdata('miscall');
        $messages['data']=$this->session->flashdata('message');


        if(!$this->session->has_userdata('logged_in')){
            $session_data = $this->session->userdata('register');
            $email=$session_data['email'];
            $user_id=$session_data['user_id'];

        }
        else{
            $session_data = $this->session->userdata('logged_in');
            $user_id=$session_data['user_id'];
            $emails=$this->profile_model->email($user_id);


        }
        $mobile = $this->session->flashdata('mobile');


        $data = $this->cognalys_model->getKey($user_id);


        foreach ($data as $object) {

            $otp=  $object->otpstart;

            $keymatch = $object->keymatch;

            $this->session->set_flashdata('otp', $otp);
            $this->session->set_flashdata('keymatch', $keymatch);



        }

        if (isset($_POST['submit'])){



            $digits = $_POST['digits'];

            if(empty($digits)){
                echo "Digits field required .Please enter last 5 digits to continue registering or try Resend ";
            }
            $keymatch = $this->session->flashdata('keymatch');
            $otp = $this->session->flashdata('otp');



            $file = file_get_contents("https://www.cognalys.com/api/v1/otp/confirm/?app_id={$this->appId}&access_token={$this->accessToken}&keymatch={$keymatch}&otp={$otp}{$digits}");


            $result = json_decode($file, true);


            if ($result['status'] == "success") {
                $is_verified= 1 ;
                $mobile = $result['mobile'] ;
                $v_code = $result['app_user_id'] ;





                $user_verify = array(

                    'is_verified' => $is_verified,
                    'v_code' => $v_code,
                    'mobile' => $mobile
                );



                $this->mobileverification_model->value_update($user_verify,$user_id);



                $this->email_verification();

                $message =  "Thank you for Registering . We have also sent you an email verification link. You can verify it whenever you like .";
                $this->session->set_flashdata('email_sent_message', $message);
                redirect(base_url());

            }

            else {
                $message = 'Sorry ! Something went wrong';
                $this->session->set_flashdata('message', $message);
                redirect('user_check');
            }

        }
        $this->load->view('Pages/header');
        $this->load->view('Users/user_check',$messages);
        $this->load->view('Pages/footer');

    }


    public function reCognlys(){
      
        //       $coun=$count->count;
//       print_r($coun);
//       die();
//        $session_data = $this->session->userdata('register');
//        $user_id=$session_data['user_id'];
//        print_r($user_id);
//        echo "nepal";
//        die();
        $data['error'] = $this->session->flashdata('error');

        if(isset($_POST['refresh'])) {

            if(!$this->session->has_userdata('logged_in')){
                $session_data = $this->session->userdata('register');
                $email=$session_data['email'];
                $user_id=$session_data['user_id'];

            }
            else{
                $session_data = $this->session->userdata('logged_in');
                $user_id=$session_data['user_id'];
                $emails=$this->profile_model->email($user_id);
                $email=$emails->email;

            }

//            print_r($user_id);
//            die();
            $mobileno = $this->userdetail_model->fetch_mobile_cog($user_id);
            if($mobileno) {
                $mobile1 = $mobileno->mobile_no;

            }



            $mobile = '+977'.$mobile1;

            $count1=$this->cognalys_model->select_count($user_id);
//        print_r($count1);

            $count=$count1+1;
//             print_r($count);


            $data = array(
                'count' => $count
            );

            $this->cognalys_model->update_count($data, $user_id);

            $final_count=$this->cognalys_model->select_count($user_id);






            if (($final_count) < 4) {

                $file = file_get_contents("https://www.cognalys.com/api/v1/otp/?app_id={$this->appId}&access_token={$this->accessToken}&mobile=" .$mobile);


                $result = json_decode($file, true);

//               print_r($result);

                if ($result['status'] == "success") {
                    $status = $result['status'];
                    $keymatch = $result['keymatch'];
                    $mobile = $result['mobile'];
                    $otpstart = $result['otp_start'];


                    $data_verify = array(

                        'status' => $status,
                        'keymatch' => $keymatch,
//                       'mobile' => $mobile,
                        'user_id' => $user_id,
                        'otpstart' => $otpstart,
                        'count' =>$final_count
                    );


                    $this->cognalys_model->data_update($data_verify,$user_id);

                    $this->session->set_flashdata('mobile', $mobile);

                    $to =  $email;
//

                    $_SESSION['email_send'] = $to;


                    redirect('user_check');

                }  else {
                    $message ="Something Went Wrong";
                    $this->session->set_flashdata('message', $message);
                    redirect('user_check');
                }

            }
            else{
                $this->session->set_flashdata('error','User can only try for three times. Please register with new number !!!');
                redirect('reCognlys');
            }
        }

        $this->load->view('Pages/header');
        $this->load->view('Users/user_check',$data);
        $this->load->view('Pages/footer');


    }

}

?>