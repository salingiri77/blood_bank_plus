 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

      protected $accessToken = 'd1a71e3cb2139319fab42cff34bc9a8931d0fb32';
    protected $appId = 'f6b5e9b6e09642089bd87cf';


    function __Construct(){
        parent::__Construct ();
        $this->load->database();
        $this->load->model('login_model');
        $this->load->model('mobileverification_model');
        $this->load->model('useraccount_model'); 
        $this->load->model('userdetail_model'); 
        $this->load->model('userverification_model'); 
        $this->load->model('profile_model'); 
        $this->load->model('cognalys_model'); 
        $this->load->library('form_validation');
        $this->load->library('session');
       // $this->load->library('controllers/cognalys');
        $this->load->helper('form');
        $this->load->helper('url');


    }


     public function register(){

        if($this->session->has_userdata('logged_in'))
            redirect('view_profile');

        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username ', 'trim|required|encode_php_tags|min_length[4]|is_unique[user_account.username]');
        $this->form_validation->set_rules('fullname', 'Name', 'trim|required|min_length[4]\'');
        $this->form_validation->set_rules('email', 'Email', 'required|encode_php_tags|regex_match[/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/]|is_unique[profile.email]');
        $this->form_validation->set_rules('gender', 'Gender', 'required');
        $this->form_validation->set_rules('blood', 'Blood', 'required');
        $this->form_validation->set_rules('dob', 'Mobile Number ', 'required');
        $this->form_validation->set_rules('mobile_no', 'Mobile Number ', 'required|encode_php_tags|regex_match[/^[0-9]{10}$/]|is_unique[user_detail.mobile_no]');
        $this->form_validation->set_rules('alt_phone', 'Alternate_Number ', 'encode_php_tags|regex_match[/^[0-9]{10}$/]|differs[mobile_no]');
        $this->form_validation->set_rules('temp_address', 'Temp_Address ', 'required|encode_php_tags|min_length[4]');
        $this->form_validation->set_rules('per_address', 'Address', 'required|encode_php_tags|min_length[4]');
        $this->form_validation->set_rules('height', 'Height ', 'required|encode_php_tags|greater_than[90]');
        $this->form_validation->set_rules('weight', 'Weight ', 'required|encode_php_tags|greater_than[40]');
        $this->form_validation->set_rules('password', 'Password', 'required|encode_php_tags|regex_match[/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}/]');
        $this->form_validation->set_rules('rpassword', 'Password', 'required|encode_php_tags|regex_match[/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}/]|matches[password]');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('Pages/header');
            $this->load->view('Users/register');
            $this->load->view('Pages/footer');
        }else {



            $this->get_data_and_process();


        }

    }

  

    public function inquiry_missed_call_url()
    {

        https://www.cognalys.com/api/v1/otp/?app_id
        return "https://www.cognalys.com/api/v1/otp/?app_id={$this->appId}&access_token={$this->accessToken}&mobile=+977" . $this->input->post('mobile_no');
    }



       protected function get_data_and_process()
    {
            $data = $this->get_profile_data();


            $id = $this->insert_data_returning_id($data);
          
            $data2 = $this->get_user_detail_from_post($id);
            $_SESSION['user_id'] = $id;


            $user_id=$_SESSION['user_id'];
            $this->userdetail_model->form_insert2($data2);

            $pass=$this->input->post('password');
            $hassed_pass=password_hash($pass,PASSWORD_DEFAULT);

         $register_user = array(
            'mobile' => $this->input->post('mobile_no'),
            'username' => $this->input->post('username'),
            'email'=>$this->input->post('email'),
            'user_id'=>$id
         );


        $this->session->set_userdata('register', $register_user);
            $data3 = array(
                'username' => html_escape($this->security->xss_clean($this->input->post('username'))),
                'password' => $hassed_pass,
                'last_login_ip' => $_SERVER['REMOTE_ADDR'],
                'last_login_date' => NOW(),
                'user_id' => $_SESSION['user_id']


            );
//           $this->hash_password($data3->password);
            $this->useraccount_model->form_insert3($data3);
//            die();
            $data_verify = array(

                'status' => 0,
                'keymatch' => 0,
                'user_id' => $_SESSION['user_id'],
                'otpstart' =>0,
                'count'=> 0
            );


          $this->cognalys_model->data_insert($data_verify);
            $is_verified= 0 ;
            $mobile = html_escape($this->security->xss_clean($this->input->post('mobile_no')));
            $v_code = 0 ;

            $user_verify = array(

               'is_verified' => $is_verified,
               'v_code' => $v_code,
               'user_id' => $user_id,
               'mobile' => $mobile
              );




        $this->mobileverification_model->value_insert($user_verify);


            $url = $this->inquiry_missed_call_url();

            $file = file_get_contents($url);
            $result = json_decode($file, true);
       // print_r($result);
       // die();






            if ($result['status'] == "success") {
                $status = $result['status'];
                $keymatch = $result['keymatch'];
                $mobile = $result['mobile'];
                $otpstart = $result['otp_start'];
                $count = '1';


                $data_verify = array(

                    'status' => $status,
                    'keymatch' => $keymatch,
                    'user_id' => $_SESSION['user_id'],
                    'otpstart' => $otpstart,
                    'count'=> $count
                );


                $this->cognalys_model->data_update($data_verify,$user_id);

                $miscall = "We have sent you a miscall . Please wait for a while";
                $this->session->set_flashdata('mobile', $mobile);
                $this->session->set_flashdata('miscall', $miscall);
                redirect('user_check');
            }else{
                $this->session->set_flashdata('error','Something went wrong!! Please click resend to verify');

                redirect('reCognlys');
            }



    }



    public function loginn()
    {
        if($this->session->has_userdata('logged_in'))
            redirect('view_profile');


        if(isset($_GET) && !empty($_GET)){




            $code = $_GET['code'];

            $result=$this->userverification_model->getCode($code);

            if($result = true){

                $status = array('email_verified' => 1 ,
                    'use_status' => 1
                );
                $this->userverification_model->user_verified($status,$code);
            }

            $this->session->set_flashdata('email',"Thank you for verifying your email.. You can Login now ..");
            redirect(base_url());

        }

//        echo $msg2;
        $this->load->view('Pages/header');
        $this->load->view('Users/login');
        $this->load->view('Pages/footer');
    }

       public function logout(){
        $this->session->unset_userdata('logged_in');
        //  $this->session->sess_destroy();
        redirect('login_user');
    }

    public function login(){
        $data['message']=$this->session->flashdata('message');
        if($this->session->has_userdata('logged_in'))
            redirect('view_profile');
        $this->load->view('Pages/header');
        $this->load->view('Users/login',$data);
        $this->load->view('Pages/footer');

    }

    public function login1()
    {


        if($this->session->has_userdata('logged_in'))
            redirect('view_profile');

        $username = $this->security->xss_clean($this->input->post('username'));

        $password = $this->security->xss_clean($this->input->post('password'));

        $hashed_pass = $this->login_model->get_password($username);
        $hash=$hashed_pass->password;

        if(empty($username) && empty($password)) {
            $this->session->set_flashdata('message', 'Username and Password field are require !!!');
            $data['message']=$this->session->flashdata('message');
            redirect('login_user');

        }
        elseif(empty($username)){
            $this->session->set_flashdata('message', 'Username field is require !!!');
            $data['message']=$this->session->flashdata('message');
            redirect('login_user');

        }
        elseif(empty($password)){
            $this->session->set_flashdata('message', 'Password field is require  !!!');
            $data['message']=$this->session->flashdata('message');
            redirect('login_user');

        }

        else{

            if (password_verify($password, $hash)) {


                $data['user_detail'] = $this->login_model->get_user($username);


                if (count($data['user_detail']) > 0) {
//
//
                    $login_user = array(
                        'username' => $data['user_detail']->username,
                        'user_id' => $data['user_detail']->user_id,
//                  'password' => $data['user_detail']->password

                    );


                    $user_data = $this->session->set_userdata('logged_in', $login_user);
                    $session_data = $this->session->userdata('logged_in');
                    $userid = $session_data['user_id'];
                    $is_verifieds = $this->login_model->check_mobile_verification($userid);
                    $is_verified = $is_verifieds->is_verified;
                    if ($is_verified == 0) {
                        $_SESSION['submit_usercheck'] = true;
                        redirect('reCognlys');
                    } else {
                        redirect('view_profile');
                    }
//                die();
//
//                redirect('view_profile');


//
                }
//

            } else {
                $this->session->set_flashdata('message', 'Invalid user or password');
                redirect('login_user');

            }
        }


    }

      protected function get_profile_data()
    {
        $data = array(

            'temp_address' =>html_escape($this->security->xss_clean( $this->input->post('temp_address'))),
            'height' =>html_escape($this->security->xss_clean($this->input->post('height'))),
            'weight' =>html_escape($this->security->xss_clean( $this->input->post('weight'))),
            'email' => html_escape($this->security->xss_clean($this->input->post('email'))),
            'status' => '1'
        );

//
        return $data;



        // $this->session->set_flashdata('register', $data);
//        $this->session->set_userdata('reg_info1', $data);

    }

     protected function get_user_detail_from_post($id)
    {
        $data2 = array(
            'name' =>html_escape($this->security->xss_clean($this->input->post('fullname'))),
            'blood_group' => html_escape($this->security->xss_clean($this->input->post('blood'))),
            'gender' => html_escape($this->security->xss_clean($this->input->post('gender'))),
            'dob' =>html_escape($this->security->xss_clean($this->input->post('dob'))),
            'user_id' => "$id",
            'per_address' => html_escape($this->security->xss_clean($this->input->post('per_address'))),
            'mobile_no' =>  html_escape($this->security->xss_clean($this->input->post('mobile_no'))),
            'alternate_no' => html_escape($this->security->xss_clean($this->input->post('alt_phone')))


        );
        $this->session->mobile_no;

        return $data2;
        //$blood_group = $this->security->xss_clean($this->input->post('blood'));

//       $this->generate_username($data2['blood_group']);
//        $bloodgrp= $this->security->xss_clean($this->input->post('blood'));
//        $six_digit=$this->generate_username();
//        $generated_username=$bloodgrp.$six_digit;


    }

        protected
    function insert_data_returning_id($data)
    {
        return $this->profile_model->form_insert($data);
    }





    public function Update_userProfile(){

        $this->load->library('form_validation');
        $this->form_validation->set_rules('fullname', 'Name', 'trim|required|min_length[4]\'');
        $this->form_validation->set_rules('alt_phone', 'Alternate_Number ', 'regex_match[/^[0-9]{10}$/]');
        $this->form_validation->set_rules('temp_address', 'Temp_Address ', 'required|min_length[4]');
        $this->form_validation->set_rules('height', 'Height ', 'required|greater_than[90]');
        $this->form_validation->set_rules('weight', 'Weight ', 'required|greater_than[40]');
        if ($this->form_validation->run() == FALSE) {
            if(!$this->session->has_userdata('logged_in')) {
                redirect('login');
            }
            $session_data = $this->session->userdata('logged_in');
            $userid=$session_data['user_id'];


            $profile_details = $this->profile_model->select_profile_details($userid);

            $user_account_details = $this->useraccount_model->select_account_details($userid);
            $user_details = $this->userdetail_model->select_user_details($userid);


            $user_detail_over['detail'] = array(
                'profile_detail'=> $profile_details,
                'account_detail'=> $user_account_details,
                'user_detail'=>$user_details
            );

//       print_r($user_detail_over);
            $this->load->view('header');
            $this->load->view('Users/userprofile',$user_detail_over);
            $this->load->view('footer');
        }else {

            $session_data = $this->session->userdata('logged_in');
            $userid = $session_data['user_id'];
            $temp_address = html_escape($this->security->xss_clean($this->input->post('temp_address')));
            $height = html_escape($this->security->xss_clean($this->input->post('height')));
            $weight = html_escape($this->security->xss_clean($this->input->post('weight')));

            $fullname = html_escape($this->security->xss_clean($this->input->post('fullname')));

            $alter_no = html_escape($this->security->xss_clean($this->input->post('alter_mobile')));
            $alter_email = html_escape($this->security->xss_clean($this->input->post('alter_email')));
            $health_defects = html_escape($this->security->xss_clean($this->input->post('health_defects')));


            $profile = array(
                'temp_address' => $temp_address,
                'height' => $height,
                'weight' => $weight
            );
            $userdetail = array(
                'name' => $fullname,
                'alternate_no' => $alter_no,
                'alternate_email' => $alter_email,
                'health_defects' => $health_defects,

            );


            $this->profile_model->update_profile_detail($profile, $userid);
            $this->userdetail_model->update_user_detail($userdetail, $userid);
            $this->session->set_flashdata('update_success','Your Profile has been Updated Successfully');
            redirect('view_profile');
        }

    }




    public function update_blood_status(){
        $session_data = $this->session->userdata('logged_in');
        $userid=$session_data['user_id'];
        $last_donate_date=$this->input->post('last_donate_date');
        $last_donate=$this->input->post('last_month');


        $userdetail = array(
            'last_donate_date'=>$last_donate_date,
            'last_three_donate'=>$last_donate
        );


        if($this->userdetail_model->update_blood_status($userdetail,$userid)){
            $this->session->set_flashdata('suc_mesge','Blood Status Profile Updated Successfully !!!');
            redirect('view_profile');
        }
        else{
            $this->session->set_flashdata('fail_mesge','Blood Status Profile Update Unsuccessfull !!!');
            redirect('view_profile');
        }

    }


}
?>
