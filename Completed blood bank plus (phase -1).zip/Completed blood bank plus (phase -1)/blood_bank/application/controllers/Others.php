<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Others extends CI_Controller {


    protected $accessToken = 'b987c49d85c616dd410be2d3588174e0b5c602cc';
    protected $appId = 'd05cc0d0795b4fa89c12e13';

    function __Construct(){
        parent::__Construct ();
        $this->load->database();
        $this->load->model('login_model');
        $this->load->model('mobileverification_model');
        $this->load->model('useraccount_model'); 
        $this->load->model('userdetail_model'); 
        $this->load->model('userverification_model'); 
        $this->load->model('profile_model');  
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');

//        $this->output->enable_profiler(TRUE);

    }

    
    /**
     * @return array
     */
//    protected function get_profile_data()
//    {
//        $data = array(
//
//            'temp_address' =>html_escape($this->security->xss_clean( $this->input->post('temp_address'))),
//            'height' =>html_escape($this->security->xss_clean($this->input->post('height'))),
//            'weight' =>html_escape($this->security->xss_clean( $this->input->post('weight'))),
//            'email' => html_escape($this->security->xss_clean($this->input->post('email'))),
//            'status' => '1'
//        );
//
////
//        return $data;
//
//
//
//        // $this->session->set_flashdata('register', $data);
////        $this->session->set_userdata('reg_info1', $data);
//
//    }

  public function username_check()
    {
        $this->useraccount_model->select_user();
    }

    public function mobile_check()
    {
        $this->insert_model->select_mobile();
    }

    public function email_check()
    {
        $this->userdetail_model->select_email();
    }

}

?>