 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {


    function __Construct(){
        parent::__Construct ();
        $this->load->database();
        $this->load->model('login_model');
        $this->load->model('mobileverification_model');
        $this->load->model('useraccount_model'); 
        $this->load->model('userdetail_model'); 
        $this->load->model('userverification_model'); 
        $this->load->model('profile_model');  
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');


    }

    public function index()
    {  
         $data['email'] = $this->session->flashdata('email');
        $data['message'] = $this->session->flashdata('email_sent_message');
        $message['messages'] = $this->session->flashdata('message');

//        $this->data['posts'] = $this->post_model->getPosts(); // calling Post model method getPosts()
        $data['result']='name';
        $this->load->view('Pages/header',$data);
        $this->load->view('Pages/main', $message);
        $this->load->view('Pages/footer');
        // load the view file , we are passing $data array to view file
    }

    public function faq()
    {
        $data['results']='name';
        $this->load->view('Pages/header',$data);
        $this->load->view('Pages/faqs');
        $this->load->view('Pages/footer');
    }

    public function privacy_policy()
    {
        $this->load->view('Pages/header');
        $this->load->view('Pages/privacypolicy');
        $this->load->view('Pages/footer');
    }


    public function terms_of_use()
    {
        $this->load->view('Pages/header');
        $this->load->view('Pages/terms_of_use');
        $this->load->view('Pages/footer');
    }


    public function view_profile(){

         $user_detail_over['update_success']=$this->session->flashdata('update_success');
        $user_detail_over['suc_mesge']=$this->session->flashdata('suc_mesge');
        $user_detail_over['fail_mesge']=$this->session->flashdata('fail_mesge');
        $user_detail_over['msg']=$this->session->flashdata('msg');
        $user_detail_over['suc_msg']=$this->session->flashdata('suc_msg');
        $user_detail_over['message']= $this->session->flashdata('message');
        if(!$this->session->has_userdata('logged_in')) {
            redirect('login');
        }
        $session_data = $this->session->userdata('logged_in');
        $userid=$session_data['user_id'];


        $profile_details = $this->profile_model->select_profile_details($userid);

        $user_account_details = $this->useraccount_model->select_account_details($userid);
        $user_details = $this->userdetail_model->select_user_details($userid);


        $user_detail_over['detail'] = array(
            'profile_detail'=> $profile_details,
            'account_detail'=> $user_account_details,
            'user_detail'=>$user_details
        );

//       print_r($user_detail_over);
        $this->load->view('Pages/header');
        $this->load->view('Users/userprofile',$user_detail_over);
        $this->load->view('Pages/footer');
    }

   

}

?>
