<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forgetpassword extends CI_Controller {


    protected $accessToken = 'b987c49d85c616dd410be2d3588174e0b5c602cc';
    protected $appId = 'd05cc0d0795b4fa89c12e13';

    function __Construct(){
        parent::__Construct ();
       $this->load->database();
        $this->load->model('login_model');
        $this->load->model('mobileverification_model');
        $this->load->model('useraccount_model'); 
        $this->load->model('userdetail_model'); 
        $this->load->model('userverification_model'); 
        $this->load->model('profile_model');  
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');



    }


    public function security_question()
    {
        $number['message2'] = $this->session->flashdata('message');
        $number['random']=$this->session->flashdata('number');
        // $user_id = $this->session->flashdata('user_id');
        $mobile_number = $_SESSION['mobile'];
        $user_ids= $this->userdetail_model->userid($mobile_number);

        $user_id = $user_ids->user_id;
        $emails = $this->profile_model->email($user_id);
        if($emails){
            $email= $emails->email;
        }

        if(isset($_POST['submit'])){
            if($this->input->post('dob') || $this->input->post('blood') || $this->input->post('mobile_no')){

                if($this->input->post('dob')){
                    $dob = $this->input->post('dob');
                    $dob_c = $this->userdetail_model->sec_dob($dob,$user_id);

                    if($dob_c){
                        $code = mt_rand('5000', '200000');
                        $data = array(
                            'forgot_password' => $code,
                        );
                        if($this->profile_model->update_profile($data,$email)){
                           $this->send_code_email($email,$code);
                        }

                    }else{
                        $this->session->set_flashdata('message','Your DOB doesnot Match');
                        redirect('security_question');
                    }
                }
                if($this->input->post('blood')){
                    $blood = $this->input->post('blood');
                    $blood_c = $this->userdetail_model->sec_blood($blood,$user_id);
                    if($blood_c){
                        $code = mt_rand('5000', '200000');
                        $data = array(
                            'forgot_password' => $code,
                        );
                        if($this->profile_model->update_profile($data,$email)){
                            $this->send_code_email($email,$code);
                        }
                    }
                    else{

                        $this->session->set_flashdata('message','Your Blood Group doesnot match');
                        redirect('security_question');

                    }
                }
                if($this->input->post('mobile_no')){
                    $mobile_no = $this->input->post('mobile_no');
                    $mobile_no_c = $this->userdetail_model->sec_mobile($mobile_no,$user_id);
                    if($mobile_no_c){

                        $code = mt_rand('5000', '200000');
                        $data = array(
                            'forgot_password' => $code,
                        );
                        if($this->profile_model->update_profile($data,$email)){
                            $this->send_code_email($email,$code);
                        }
                    }
                    else{

                        $this->session->set_flashdata('message','Your alternate mobile number doesnot match');
                        redirect('security_question');

                    }
                }


            }

            else{
                $this->session->set_flashdata('message','Please fill the answer field');
                redirect('security_question');

            }
        }
        else {
            $this->load->view('Pages/header');
            $this->load->view('Forgetpassword/security_question', $number);
            $this->load->view('Pages/footer');
        }
    }


    public function send_code_email($email,$code){
        $to = $email;
//                            $link = base_url()."new_password";
        $this->load->library('email',array('mailtype'=>'html'));
        $this->email->initialize(array(

            'protocol' => 'smtp',
            'smtp_host' => 'smtp.sendgrid.net',
            'smtp_user' => 'noreply@technorio.com',
            'smtp_pass' => 'N0replyTec#n0ri0',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n"
        ));
        $this->email->from('noreply@bloodbankplus.org', 'BloodBank+');
        $this->email->to($to);

        $this->email->subject('Reset Password');
        $this->email->message('Your code is: '. $code );
        if($this->email->send()){
            $data['submit_success'] = true;
            $this->load->view('Pages/header');
            $this->load->view('Forgetpassword/new_password', $data);
            $this->load->view('Pages/footer');

        }
    }


    public function forget_password1()
    {   $data2['message0'] = $this->session->flashdata('emails');
        $data2['message2'] = $this->session->flashdata('message2');
        $this->load->view('Pages/header');
        $this->load->view('Forgetpassword/forget_password',$data2);
        $this->load->view('Pages/footer');
    }

    public function forget_password(){




        $this->load->library('form_validation');
        $this->form_validation->set_rules('mobile', 'Mobile Number ', 'required|regex_match[/^[0-9]{10}$/]');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('Pages/header');
            $this->load->view('Forgetpassword/forget_password');
            $this->load->view('Pages/footer');
        } else {
            $mobileno=$this->input->post('mobile');
            $_SESSION['mobile'] = $mobileno;
            $mobile_check = $this->userdetail_model->user_check_mobile($mobileno);
            $user_id= $this->userdetail_model->user_mobile_email_check($mobileno);
            $email_exist = $this->userverification_model->email_check($user_id);
            $username_password = $this->useraccount_model->username_password($user_id);
            $username=  $username_password->username;
            $password= $username_password->password;
            if ($mobile_check) {
                if($email_exist){
                    $email_status = $this->userverification_model->user_email_status($user_id);
                    if ($email_status == 1) {
                        $min=1;
                        $max=3;
                        $number=rand($min,$max);
                        $this->session->set_flashdata('number',$number);
                        $this->session->set_flashdata('user_id',$user_id);
                        redirect('security_question');
                        //echo "User Email is already Verified";
                    }
                    else{
//                        echo "Username:".$username."Password:".$password;
                        echo "SMS sent to user with username and password";
                        redirect(base_url());

                    }

                }
                else{
//                    echo "Username:".$username."Password:".$password;
                    $this->session->set_flashdata('message2','SMS sent to user with username and password');
//                    echo "SMS sent to user with username and password";
                    redirect(base_url());
                }

            }
            else {
                $this->session->set_flashdata('message2','User with mobile number does not Exist');
                redirect('forget_password1');
            }
        }

    }



    public function new_password(){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('code', 'Code', 'required|min_length[4]|max_length[7]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|min_length[5]|max_length[125]');
        $this->form_validation->set_rules('password1', 'Password', 'required|min_length[5]|max_length[15]');
        $this->form_validation->set_rules('password2', 'Confirmation Password', 'required|min_length[5]|max_length[15]|matches[password1]');



        // Get Code from URL or POST and clean up
//        if ($this->input->post()) {
//            $data['code'] = $this->input->post('code');
//        } else {
//            $data['code'] = $this->uri->segment(3);
//        }

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('Pages/header');
            $this->load->view('Forgetpassword/new_password');
            $this->load->view('Pages/footer');
        } else {
            // Does code from input match the code against the // email
           
            $email = $this->input->post('email');
            $code = $this->input->post('code');
            // print_r($code);
            if (!$this->profile_model->does_code_match($code, $email)) {
                $this->session->set_flashdata('emails','Sorry Your Email and Code Mismatched . Try Again !!! ');
                redirect ('forget_password1');
            } else {// Code does match
            
                $user_ids=$this->profile_model->select_user_id($email);
                $user_id=$user_ids->user_id;
//                print_r($user_id);
//                die();
                $pass=$this->input->post('password1');
                $hash = password_hash($pass,PASSWORD_DEFAULT);

                $data = array(
                    'password' => $hash
                );

                if($this->useraccount_model->update_user($data, $user_id)){
                    $data['message123'] = "Your Password has been updated successfully . You can login with your new password now !!!";
                    $this->load->view('Pages/header');
                    $this->load->view('Users/login',$data);
                    $this->load->view('Pages/footer');
                }
//                print_r($email);

            }
        }
    }

    public function change_password(){



            $this->load->library('form_validation');
            $this->form_validation->set_rules('old_password', 'Old Password', 'trim|required');
            $this->form_validation->set_rules('new_password', 'New Password ', 'required|encode_php_tags|regex_match[/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}/]');
            $this->form_validation->set_rules('confirm_password', 'Confirm', 'required|encode_php_tags|regex_match[/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}/]|matches[new_password]');

            $old_password=$this->input->post('old_password');
            $new_password=$this->input->post('new_password');
            $confirm_password=$this->input->post('confirm_password');

            if ($this->form_validation->run() == FALSE) {
                $session_data = $this->session->userdata('logged_in');
                $userid=$session_data['user_id'];

                $profile_details = $this->profile_model->select_profile_details($userid);

                $user_account_details = $this->useraccount_model->select_account_details($userid);
                $user_details = $this->userdetail_model->select_user_details($userid);


                $user_detail_over['detail'] = array(
                    'profile_detail'=> $profile_details,
                    'account_detail'=> $user_account_details,
                    'user_detail'=>$user_details
                );

                $this->load->view('Pages/header');
             $this->load->view('Users/userprofile',$user_detail_over);
                $this->load->view('Pages/footer');
            } else {

//            if (!$old_password) {
//
//                $this->session->set_flashdata('msg', 'Old Password Field Is Required to Update Password');
//                redirect('view_profile');
//            }
//            if (!$new_password) {
//
//                $this->session->set_flashdata('msg', 'New Password Field Is Required to Update Password');
//                redirect('view_profile');
//            }
//            if (!$confirm_password) {
//
//                $this->session->set_flashdata('msg', 'Confirm Password Field Is Required to Update Password');
//                redirect('view_profile');
//            }

            if($old_password==$new_password){
                $this->session->set_flashdata('msg', 'Password already in use ,Try new one');
                redirect('view_profile');
            }

            if ($old_password && $new_password && $confirm_password) {
                $session_data = $this->session->userdata('logged_in');
                $user_id = $session_data['user_id'];


                if ($new_password == $confirm_password) {
//
                    $new_pass_hash = password_hash($new_password, PASSWORD_DEFAULT);
                    $old_password_db = $this->useraccount_model->get_OldPass($user_id);
                    $old_password_data = $old_password_db->password;

                    if (password_verify($old_password, $old_password_data)) {

                        $password = array(
                            'password' => $new_pass_hash,

                        );

                        if ($this->useraccount_model->change_password($password, $user_id)) {
                            $this->session->set_flashdata('suc_msg', 'Your Password is Updated Successfully');
                            redirect('view_profile');
                        }
                    } else {

                        $this->session->set_flashdata('msg', 'Your Old Password did not Match . Make Sure you enter correct Password');
                        redirect('view_profile');
                    }

                } else {
                    $this->session->set_flashdata('msg', 'Password confirmation not matched');
                    redirect('view_profile');
                }
            }
        }

    }


}