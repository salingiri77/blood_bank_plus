$(document).ready(function(){
    $('#mobile_no').keyup(function(){
        var mobile = $(this).val(); // Get username textbox using $(this)
        var Result = $('#message2'); // Get ID of the result DIV where we display the results
        if(mobile.length > 2) { // if greater than 2 (minimum 3)
            Result.html('Loading...'); // you can use loading animation here
            var dataPass = 'action=availability&mobile='+mobile;
            $.ajax({ // Send the username val to available.php
                type : 'POST',
                data : dataPass,
                url  : 'check_mobile',
                success: function(responseText){ // Get the result
                    //alert(responseText);
                    if(responseText == 0){
                        Result.html('<span class="success">Available</span>');
                    }
                    else if(responseText > 0){
                        Result.html('<span class="error">Taken</span>');
                    }
                    else{
                        alert('Problem with sql query');
                    }
                }
            });
        } else {
            Result.html('Enter valid number');
        }
//                                                if(username.length == 0) {
//                                                    Result.html('');
//                                                }
    });
});


$(document).ready(function(){
    $('#username').keyup(function(){
        var user_name = $(this).val(); // Get username textbox using $(this)
        var Result = $('#message1'); // Get ID of the result DIV where we display the results
        if(user_name.length > 2) { // if greater than 2 (minimum 3)
            Result.html('Loading...'); // you can use loading animation here
            var dataPass = 'action=availability&user_name='+user_name;
            $.ajax({ // Send the username val to available.php
                type : 'POST',
                data : dataPass,
                url  : 'check_user',
                success: function(responseText){ // Get the result
                    // alert(responseText);
                    if(responseText == 0){
                        Result.html('<span class="success">Available</span>');
                    }
                    else if(responseText > 0){
                        Result.html('<span class="error">Taken</span>');
                    }
                    else{
                        alert('Problem with sql query');
                    }
                }
            });
        } else {
            Result.html('Enter valid name');
        }
//                                                if(username.length == 0) {
//                                                    Result.html('');
//                                                }
    });
});

$(document).ready(function(){
    $('#email').keyup(function(){
        var useremail = $(this).val(); // Get username textbox using $(this)
        var Result = $('#message'); // Get ID of the result DIV where we display the results
        if(useremail.length > 2) { // if greater than 2 (minimum 3)
            Result.html('Loading...'); // you can use loading animation here
            var dataPass = 'action=availability&useremail='+useremail;
            $.ajax({ // Send the username val to available.php
                type : 'POST',
                data : dataPass,
                url  : 'check_email',
                success: function(responseText){ // Get the result
//                                                            alert(responseText);
                    if(responseText == 0){
                        Result.html('<span class="success">Available</span>');
                    }
                    else if(responseText > 0){
                        Result.html('<span class="error">Taken</span>');
                    }
                    else{
                        alert('Problem with sql query');
                    }
                }
            });
        } else {
            Result.html('Enter valid email address');
        }
//                                                if(username.length == 0) {
//                                                    Result.html('');
//                                                }
    });
});