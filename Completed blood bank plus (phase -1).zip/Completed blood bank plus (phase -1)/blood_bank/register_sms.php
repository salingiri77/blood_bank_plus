<?php 

    //getting data from user sms through get method and storing value in database
 // if (isset($_POST) && !empty($_POST) ) {

                // $user_number= $_POST['from'];
                // $short_code = $_POST['to'];
                // $user_text  = $_POST['text'];
                // $keyword    = $_POST['keyword']; 

                $user_number ='9818310675';
                $short_code = '33208';
                $user_text = "REG bp SALINGIRI";
                $keyword = "BBP"; 

                $result =  (explode(" ",$user_text));
               
                $data1 = "REG";
                $upper_case_bg = strtoupper($result['1']);
                $data2 = array( '0'=> 'AP',
                                '1'=> 'AN',
                                '2'=> 'ABP',
                                '3'=> 'ABN',
                                '4'=> 'BP',
                                '5'=> 'BN',
                                '6'=> 'OP',
                                '7'=> 'ON',
                                '8'=> 'A+',
                                '9'=> 'A-',
                                '10'=> 'AB+',
                                '11'=> 'AB-',
                                '12'=> 'B+',
                                '13'=> 'B-',
                                '14'=> 'O+',
                                '15'=> 'O-'
                              
                    );


           
                if($result['0'] == $data1 ){


                
                    for($i=0; $i<16; $i++){
                    
                        if($upper_case_bg == $data2[$i]){
                          
                            $blood_group = $upper_case_bg;
                            $user_full_name = $result['2'];
                            $mobile_number = $user_number;
                            $randomno = mt_rand(100000,999999);
                            $generated_username= $blood_group.$randomno;
                            $generated_password= mt_rand(100000,999999);
                          

                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "bloodbank";

                     // Create connection
                        $conn = new mysqli ($servername, $username, $password, $dbname);
                         if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }
                            $date_time = mt_rand(100000,999999);
                            $value=$date_time;
                            $sql3 = "INSERT INTO profile (created)
                            VALUES ('$date_time')";
                            $result3=$conn->query($sql3);

                            $sql4 = "SELECT * FROM profile WHERE created=$value";
                            $result4=$conn->query($sql4);
                            if ($result4->num_rows > 0) {
        // output data of each row
                                 while($row = $result4->fetch_assoc()) {
                                    $user_id = $row["user_id"];
                                                   }
                                      } else {
                                                 echo "0 results";
                                             }               
                            
                            $sql1 = "INSERT INTO user_account (username,password,user_id)
                            VALUES ('$generated_username', '$generated_password', '$user_id')";
                            $result1=$conn->query($sql1);
                            $sql2 = "INSERT INTO user_detail (mobile_no, name,user_id)
                            VALUES ('$mobile_number', '$user_full_name', '$user_id')";
                            $result2=$conn->query($sql2);
                           if($result1 = true){
                            die("You have been registered successfully.Username: ".$generated_username."Password: ".$generated_password);
                           }
                           else{
                            die("Sorry something went wrong");
                           }
                        }

           
                       
                    }


                }
//           }

   ?>
